# Classic ASP 前端升級 — 跨瀏覽器現代化（向下相容 IE8）

**升級目標：讓頁面在現代瀏覽器（Chrome / Edge）正確運作，同時向下相容 IE8。**
現代瀏覽器是主要品質標準，IE8 是向下相容要求。禁止任何 .NET 轉換或後端改動。
詳細參考請使用 skill：`.github/skills/classic-asp-frontend-upgrade/`

---

## 專案副檔名設定

<!-- SETUP: 依你的專案實際使用的副檔名調整以下清單。不確定的話，保留預設值即可。 -->

本專案的 ASP 頁面與 Include 檔案使用以下副檔名，**全部視同 ASP 頁面處理**：

- `*.asp` — 主要 ASP 頁面，也可能用於 Include 檔案，是前端升級的主要對象
- `*.inc` — Include 檔案，可能包含 HTML / CSS / JS，依內容判斷升級範圍

<!-- SETUP: 若你的專案有以下額外副檔名，取消下方對應行的註解：
- `*.vs`  — Include 檔案（含前端 VBScript），是升級對象，需全面檢查與重寫
- `*.vbs` — 純 VBScript 腳本，僅套用 JavaScript 規則，無 CSS / HTML 檢查
-->

---

## 🛑 升級範圍限制（絕對禁止，每次升級前先確認）

升級是「**跨瀏覽器現代化**」，不是「功能重構」。以下四條為硬性邊界：

1. **禁止修改 VBScript 後端邏輯** — `<%...%>` 與 `<%=...%>` 內的任何內容一律不動
2. **禁止改變 HTML 結構** — class、id、標籤層級、元素的嵌套關係都不能改
3. **禁止改變表單欄位的 `name` 屬性** — 後端用 `Request.Form("name")` 接收，改名等於資料消失
4. **禁止改變 AJAX 的 URL、傳送參數與回傳資料解析邏輯** — 只能把 `fetch` 語法改成 `$.ajax()`，URL 和參數不動

---

## 🎯 CSS 升級策略：三類分法

### 類別 A：通用基礎（現代瀏覽器 + IE8 都直接支援）

直接使用，不需要特別處理：

- **float + clearfix 佈局** — 所有瀏覽器原生支援，用來替代 flex/grid
- **`border-radius` / `box-shadow`** — 直接寫，IE8 優雅降級忽略（不報錯）
- **單冒號偽元素 `:after`** — IE8 和現代瀏覽器都支援
- **`px` 單位** — 所有瀏覽器支援

### 類別 B：現代語法為主 + IE8 fallback（兩行都要寫）

```css
/* ✅ opacity：標準寫法在上，IE8 filter 在下 */
.element {
    opacity: 0.8;                    /* 標準，現代瀏覽器使用這行 */
    filter: alpha(opacity=80);       /* IE8 fallback */
}

/* ✅ rgba()：solid 色先寫（IE8 讀到這就停），rgba 覆蓋（現代瀏覽器讀這行）*/
.element {
    background: #000000;             /* IE8 fallback */
    background: rgba(0, 0, 0, 0.5); /* 現代瀏覽器使用這行 */
}
```

### 類別 C：IE8 完全不支援，改用通用替代

| 禁用 | 替代 | 說明 |
|------|------|------|
| `display: flex` / `grid` | float + clearfix | IE8 完全不支援 |
| `calc()` | 固定 px 或 margin offset | IE8 不支援 |
| CSS 變數 `var(--)` | 直接寫值 | IE8 不支援 |
| `rem` 單位 | `px` | IE8 不支援 |
| 雙冒號 `::after` | 單冒號 `:after` | IE8 不支援，單冒號現代瀏覽器也完全支援 |

---

## 🎯 JavaScript 升級策略：選用通用子集

以下語法在**所有目標瀏覽器都正確運作**，不是「降級」而是選用通用子集：

| 使用 | 取代 | 理由 |
|------|------|------|
| `var` | `let` / `const` | 所有瀏覽器支援，現代瀏覽器完全正常 |
| `function(){}` | 箭頭函數 `=>` | 所有瀏覽器支援 |
| 字串串接 | template literal | 所有瀏覽器支援 |
| `$.ajax()` | `fetch` / `Promise` | jQuery 1.12.4 同時支援 IE8 和現代瀏覽器 |
| jQuery `$()` | `querySelector` | 跨瀏覽器選取一致 |
| jQuery `.on()` | `addEventListener` | jQuery 內部處理 IE8/現代差異 |
| prototype 模式 | ES6 `class` | 所有瀏覽器支援 |

**jQuery 只能用 1.12.4** — 最後一個同時支援 IE8 和現代瀏覽器的版本。
裸 `console.log` 必須包 `if(window.console)` 保護 — IE8 DevTools 未開啟時會 crash。

---

## 🔴 HTML / VBScript 規則

- **`<%...%>` 和 `<%=...%>` 區塊一律不動**，字元完全保留
- 每個修改的元素或區塊加 `<!-- [ASP-UPGRADE] 說明 -->` 標記
- `<head>` 必須有 `<meta http-equiv="X-UA-Compatible" content="IE=edge">`
- `<!DOCTYPE html>` 必須在檔案最頂端

---

## 🟠 升級完成後 — 先測試再詢問（順序不可顛倒）

### Step 1：執行靜態掃描

```powershell
.\scripts\test-compat.ps1 -File 剛升級的檔案.asp
.\scripts\test-compat.ps1 -Dir .
```

```bash
node scripts/test-compat.js 剛升級的檔案.asp
```

- 出現 ❌ → 立即修正，重新掃描，直到全部 ✅
- 全部 ✅ → 進入 Step 2

### Step 2：跨瀏覽器手動確認（靜態掃描通過後輸出）

逐字輸出以下提醒：

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✅ 靜態掃描通過，佈署前請完成以下手動確認：

【現代瀏覽器（Chrome / Edge）— 主要品質驗收】
  □ 頁面正常載入，無 JS 錯誤（F12 Console）
  □ 表單送出功能正常
  □ AJAX 請求正常回應（F12 Network）
  □ 頁面排版正確，視覺符合升級目標

【IE11 文件模式 IE8（F12 → 文件模式 → 8）— 向下相容驗收】
  □ 頁面可正常載入
  □ 核心功能可操作
  □ 無 JS 錯誤（F12 Console）

確認完畢後回覆「完成」。
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

### Step 2.5：將確認結果寫入報告

使用者回覆「完成」後，提示執行以下指令將結果附加至 `reports/<檔名>.report.md`：

```powershell
.\scripts\test-compat.ps1 -File [剛升級的檔案] -Confirm
```
```bash
node scripts/test-compat.js [剛升級的檔案] --confirm
```

執行完成後進入 Step 3。

### Step 3：佈署詢問（Step 2.5 完成後才執行）

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✅ 升級完成：[頁面名稱]
📋 測試：[N] 項全部通過
修改檔案：[檔案清單]

是否將本次變更紀錄到 DEPLOYMENT.md？
  [Y] 是 → 請提供：上線日期 / 負責人 / 備註（選填）
  [N] 否 → 略過
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```
