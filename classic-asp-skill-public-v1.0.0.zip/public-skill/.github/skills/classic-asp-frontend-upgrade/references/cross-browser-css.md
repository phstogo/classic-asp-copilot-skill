# CSS 跨瀏覽器相容 Reference

## 升級策略：三類分法

| 類別 | 說明 | 做法 |
|---|---|---|
| **A. 通用基礎** | 現代瀏覽器 + IE8 都直接支援 | 直接使用 |
| **B. 雙寫 fallback** | 現代語法為主，IE8 需要額外一行 | 兩行都寫，順序有講究 |
| **C. 通用替代** | IE8 完全不支援，改用所有瀏覽器都懂的寫法 | 替換語法 |

---

## 類別 A：通用基礎（直接使用）

### Float + Clearfix 佈局

float 是所有瀏覽器（含 IE8）都支援的佈局基礎。用來替代 flex/grid：

```css
/* ✅ 雙欄佈局 — 現代瀏覽器和 IE8 都正確 */
/* [ASP-UPGRADE] 取代 table 版面或 flexbox */
.layout { zoom: 1; } /* zoom:1 補 IE8 hasLayout */
.layout:after { content: ""; display: table; clear: both; }
.layout-sidebar { float: left;  width: 200px; }
.layout-main    { margin-left: 220px; }

/* ✅ 標準 clearfix */
.clearfix { zoom: 1; }
.clearfix:after { content: ""; display: table; clear: both; }
```

### 偽元素：單冒號語法

IE8 只支援單冒號，但現代瀏覽器也向下相容單冒號，所以直接用單冒號：

```css
/* ✅ 單冒號 — IE8 和所有現代瀏覽器都支援 */
.clearfix:after { content: ""; display: table; clear: both; }

/* ❌ 雙冒號 — IE8 不支援，禁用 */
.clearfix::after { content: ""; display: table; clear: both; }
```

### border-radius / box-shadow：優雅降級

直接寫現代語法，IE8 自動忽略（不顯示效果但不會出錯）：

```css
/* ✅ 優雅降級 — 現代瀏覽器顯示效果，IE8 忽略不報錯 */
.card {
    border-radius: 6px;
    box-shadow: 0 2px 6px rgba(0,0,0,0.15);
}

/* ✅ 若需 IE8 也顯示圓角/陰影，加 PIE.htc */
.card {
    border-radius: 6px;
    box-shadow: 0 2px 6px rgba(0,0,0,0.15);
    behavior: url(/assets/PIE.htc); /* 路徑必須為絕對路徑 */
}
```

---

## 類別 B：雙寫 fallback（現代語法為主）

### opacity（標準寫法 + IE8 filter:alpha）

```css
/* ✅ opacity 是標準，filter:alpha 是 IE8 fallback */
.overlay {
    opacity: 0.8;               /* 標準寫法，所有現代瀏覽器使用這行 */
    filter: alpha(opacity=80);  /* IE8 fallback，值為 opacity × 100 */
}

/* 常用值對照 */
/* opacity: 0.9  → filter: alpha(opacity=90)  */
/* opacity: 0.75 → filter: alpha(opacity=75)  */
/* opacity: 0.5  → filter: alpha(opacity=50)  */
```

### rgba()（現代標準 + IE8 solid 降級色）

CSS cascade 特性：IE8 讀不懂 rgba() 就停在上方那行；現代瀏覽器兩行都讀，後者覆蓋前者：

```css
/* ✅ solid 色先寫（IE8 fallback），rgba 後寫（現代瀏覽器用這行）*/
.overlay {
    background: #000000;             /* IE8 fallback — 讀不懂 rgba 就用這行 */
    background: rgba(0, 0, 0, 0.5); /* 現代瀏覽器覆蓋為半透明 */
}

.highlight {
    color: #336699;                  /* IE8 fallback */
    color: rgba(51, 102, 153, 0.9); /* 現代瀏覽器 */
}
```

---

## 類別 C：通用替代（IE8 完全不支援）

### Flexbox / Grid → Float

```css
/* ❌ flexbox — IE8 完全不支援 */
.container { display: flex; justify-content: space-between; align-items: center; }
.item { flex: 1; }

/* ✅ float — 現代瀏覽器和 IE8 都支援，視覺效果相同 */
/* [ASP-UPGRADE] flex 改 float 佈局 */
.container { zoom: 1; }
.container:after { content: ""; display: table; clear: both; }
.item { float: left; width: 48%; margin-right: 4%; }
```

```css
/* ❌ grid — IE8 完全不支援 */
.grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; }

/* ✅ float grid */
/* [ASP-UPGRADE] grid 改 float 版面 */
.grid { zoom: 1; }
.grid:after { content: ""; display: table; clear: both; }
.grid-col { float: left; width: 33.33%; padding: 0 8px; }
.grid-col:last-child { margin-right: 0; }
```

### calc() → 固定 px 或 margin offset

```css
/* ❌ calc() — IE8 不支援 */
.content { width: calc(100% - 220px); }

/* ✅ margin offset — 所有瀏覽器正確 */
/* [ASP-UPGRADE] calc() 改為 margin offset */
.sidebar { float: left; width: 200px; }
.content  { margin-left: 220px; }
```

### CSS 變數 → 直接寫值

```css
/* ❌ CSS 自訂屬性 — IE8 不支援 */
:root { --primary: #336699; --spacing: 16px; }
.btn { color: var(--primary); padding: var(--spacing); }

/* ✅ 直接寫值 — 所有瀏覽器正確 */
/* [ASP-UPGRADE] CSS 變數展開為直接值 */
.btn { color: #336699; padding: 16px; }
```

### rem → px

```css
/* ❌ rem — IE8 不支援 */
.text { font-size: 1.6rem; margin-bottom: 2rem; }

/* ✅ px — 所有瀏覽器正確 */
/* [ASP-UPGRADE] rem 改 px（基準 1rem = 16px）*/
.text { font-size: 16px; margin-bottom: 20px; }
```

---

## IE 條件式注解（額外 IE8 修補用）

```html
<!--[if IE 8]>
<link rel="stylesheet" href="/assets/css/ie8-fixes.css">
<![endif]-->

<!--[if lt IE 9]>
<link rel="stylesheet" href="/assets/css/lt-ie9.css">
<![endif]-->
```

---

## 自我檢查清單

### 相容性規則（靜態掃描涵蓋）

- [ ] 無 `display: flex` 或 `display: grid`
- [ ] 無 `calc()`
- [ ] 無 `var(--)` CSS 變數
- [ ] 無 `rem` 單位（已改 px）
- [ ] `opacity` 有伴隨 `filter: alpha()`（缺一不可）
- [ ] `rgba()` 上方有 solid 色 fallback
- [ ] `<head>` 有 `X-UA-Compatible` meta
- [ ] 偽元素使用單冒號 `:after`，無雙冒號 `::after`

### 視覺品質確認（人工）

- [ ] Chrome/Edge 排版視覺正確（主要驗收）
- [ ] `opacity` 在 Chrome/Edge 顯示正確透明度
- [ ] `rgba()` 在 Chrome/Edge 顯示正確半透明效果
- [ ] `border-radius` / `box-shadow` 在 Chrome/Edge 正確顯示
- [ ] IE11 IE8 文件模式下核心功能可操作（向下相容驗收）
- [ ] `border-radius` / `box-shadow` 在 IE8 選擇優雅降級或 PIE.htc
