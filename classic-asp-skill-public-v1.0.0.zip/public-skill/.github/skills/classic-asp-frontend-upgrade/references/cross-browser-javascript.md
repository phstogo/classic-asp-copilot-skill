# JavaScript 跨瀏覽器相容 Reference

## 升級策略：選用所有瀏覽器都支援的語法子集

以下替換方案**不是「降級到 IE8」，而是選用在所有目標瀏覽器（Chrome、Edge、Firefox、Safari、IE8）都正確運作的語法**。這些語法在現代瀏覽器完全正常，同時 IE8 也支援。

## 升級範圍邊界（改語法，不改邏輯）

| 禁止 | 具體說明 |
|---|---|
| 改 AJAX URL | `url: 'handler.asp'` 原封不動，只改 `fetch` → `$.ajax` 語法 |
| 改 AJAX 傳送參數 | `data: { id: itemId }` 的 key 和 value 邏輯不動 |
| 改 AJAX 回傳解析 | `success: function(r){}` 裡對 `r` 的處理邏輯不動 |
| 改表單欄位 `name` | `name="xxx"` 是後端 `Request.Form("xxx")` 的鍵，絕對不動 |

---

## 變數宣告

```javascript
// ❌ ES6（IE8 不支援）
let count = 0;
const MAX = 10;

// ✅ var — 所有瀏覽器（含 IE8）都正確運作
var count = 0;
var MAX = 10;
```

## 函式

```javascript
// ❌ 箭頭函數（IE8 不支援）
var add = (a, b) => a + b;
var items = list.map(x => x.name);

// ✅ function expression — 所有瀏覽器都正確運作
var add = function(a, b) { return a + b; };
var items = $.map(list, function(x) { return x.name; });
```

> ⚠️ **轉換時必須保留主體邏輯**：`(e) => { doSomething(e); return true; }` → `function(e) { doSomething(e); return true; }`  
> 不可轉換成空的 `function() {}`，否則靜態掃描會偵測到回歸錯誤。

## 字串

```javascript
// ❌ Template literal（IE8 不支援）
var msg = `Hello ${name}，共 ${n} 筆`;

// ✅ 字串串接 — 所有瀏覽器都正確運作
var msg = "Hello " + name + "，共 " + n + " 筆";
```

> ⚠️ **轉換後確認串接正確**：不能出現 `"Hello " + null + " 筆"` 或 `undefined` 出現在字串結果中。

## 陣列操作

```javascript
// ❌ .forEach / .map（IE8 原生不支援）
items.forEach(function(item) { process(item); });

// ✅ jQuery $.each — 所有瀏覽器都正確運作
$.each(items, function(i, item) { process(item); });

// ✅ 傳統 for 迴圈 — 所有瀏覽器都正確運作
for (var i = 0; i < items.length; i++) { process(items[i]); }
```

## DOM 選取

```javascript
// ❌ querySelector（IE8 不支援）
document.querySelector('.btn');
document.querySelectorAll('li.active');

// ✅ jQuery $() — 跨瀏覽器一致，現代瀏覽器和 IE8 都正確
$('.btn');
$('li.active');

// ✅ 原生 DOM（IE8 原生支援）
document.getElementById('myId');
document.getElementsByTagName('div');
```

## 事件綁定

```javascript
// ❌ addEventListener（IE8 用 attachEvent，行為不同）
el.addEventListener('click', handler);

// ✅ jQuery .on() — 跨瀏覽器一致，內部處理 IE8/現代差異
$(el).on('click', handler);

// ✅ 手動跨瀏覽器（不用 jQuery 時）
if (el.addEventListener) {
    el.addEventListener('click', handler);
} else {
    el.attachEvent('onclick', handler);
}
```

## AJAX

```javascript
// ❌ fetch / Promise（IE8 不支援）
fetch('/handler.asp').then(function(r) { return r.json(); });

// ✅ jQuery $.ajax — 跨瀏覽器一致，jQuery 1.12.4 同時支援 IE8 和現代瀏覽器
// 重要：url、data、success 邏輯必須與原始 fetch 完全一致
$.ajax({
    url: 'handler.asp',                    // ← 保持原始 URL，不能改
    type: 'POST',
    data: { id: itemId, action: 'save' }, // ← 保持原始參數，不能改
    success: function(response) {
        // ← 保持原始回傳解析邏輯，不能改
    },
    error: function(xhr, status, err) {
        // 錯誤處理
    }
});
```

> ⚠️ `$.ajax()` 必須帶參數。靜態掃描會偵測到 `$.ajax()` 空呼叫並回報回歸錯誤。

## JSON

```javascript
// JSON.parse / JSON.stringify 在 IE8 原生支援
// 建議加保護（IE7 無 JSON）：
if (typeof JSON !== 'undefined') {
    var data = JSON.parse(responseText);
}
```

## console

```javascript
// ❌ 裸用 — IE8 DevTools 未開啟時 window.console 不存在，會 crash
console.log('debug');

// ✅ 加保護（現代瀏覽器也正常執行）
if (window.console && window.console.log) {
    window.console.log('debug');
}
```

## 物件模式

```javascript
// ❌ ES6 class（IE8 不支援）
class MyWidget {
    constructor(el) { this.el = el; }
    init() {}
}

// ✅ Prototype 模式 — 所有瀏覽器都正確運作
function MyWidget(el) { this.el = el; }
MyWidget.prototype.init = function() {};
```

## 模組

```javascript
// ❌ import / export（IE8 完全不支援）
import { utils } from './utils.js';
export default MyWidget;

// ✅ IIFE 或全域變數 — 所有瀏覽器都正確運作
var MyWidget = (function() {
    function MyWidget(el) { this.el = el; }
    return MyWidget;
})();
```

---

## 必備 Polyfill

| 功能 | Polyfill | 需要條件 |
|---|---|---|
| HTML5 語義標籤 | `html5shiv.min.js` | 使用 `<header>` `<section>` 等標籤 |
| JSON | `json2.min.js` | 需同時支援 IE7 |
| CSS3 視覺效果 | `PIE.htc` | border-radius / box-shadow 需在 IE8 顯示 |

```html
<!--[if lt IE 9]>
<script src="/assets/js/lib/html5shiv.min.js"></script>
<script src="/assets/js/lib/json2.min.js"></script>
<![endif]-->
<script src="/assets/js/lib/jquery-1.12.4.min.js"></script>
```

---

## 自我檢查清單

### 相容性規則（靜態掃描涵蓋）

- [ ] 無 `let` / `const`（已改 `var`）
- [ ] 無箭頭函數 `=>`（已改 `function(){}`）
- [ ] 無 template literal `` ` ` ``（已改字串串接）
- [ ] 無 `addEventListener`（已改 jQuery `.on()` 或 attachEvent fallback）
- [ ] 無 `fetch` / `Promise`（已改 `$.ajax()`）
- [ ] 無 `querySelector`（已改 jQuery `$()`）
- [ ] 無 ES6 `class` / `import` / `export`
- [ ] 無裸 `console.log`（有 `if(window.console)` 保護）
- [ ] jQuery 版本為 1.12.4

### 回歸偵測（靜態掃描涵蓋）

- [ ] 箭頭函數轉換後函式主體完整（無空的 `function(){}`）
- [ ] 無重複 `var var` 宣告
- [ ] `$.ajax()` 有傳入參數（url、type、success 等）
- [ ] 字串串接後無裸 `null` 或 `undefined`

### 邊界確認（人工）

- [ ] AJAX 的 `url` 與原始相同
- [ ] AJAX 的 `data` 鍵值與原始相同
- [ ] AJAX 的 `success` 邏輯與原始相同
- [ ] 表單 `name` 屬性未被更改
