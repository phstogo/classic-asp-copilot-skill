# HTML 升級模式 Reference

## 升級策略：現代化優先，IE8 向下相容

HTML 升級的目標是讓頁面在**現代瀏覽器正確渲染**，同時對 IE8 保持向下相容：

- **優先使用語義化標籤**（搭配 html5shiv，IE8 也支援）
- **table 布局改為 CSS float**（所有瀏覽器通用基礎）
- **IE8 不支援的 CSS**（如 border-radius）：現代瀏覽器全功能，IE8 優雅降級
- **`X-UA-Compatible: IE=edge`**：讓 IE 用最高版本引擎渲染，不鎖在 IE8 相容模式

---

## 升級範圍邊界（每次操作前確認）

HTML 升級只允許**改寫展示層結構**，以下四件事絕對不動：

| 禁止 | 具體說明 |
|------|---------|
| `<%...%>` / `<%=...%>` 內容 | 字元逐字保留，包含空白與換行 |
| HTML 結構的 class / id | 後端可能用 `document.getElementById` 或其他方式依賴 |
| 表單欄位的 `name` 屬性 | `Request.Form("name")` 依賴此鍵，改名等於資料消失 |
| `<form>` 的 `action` 和 `method` | 後端 POST/GET 接收端點，不能改 |

**只允許改**：外層包裝 `<div>`、class 名稱（新增）、移除 `<table>` 布局標籤、移除 `<font>` / `bgcolor` / `align` 等廢棄屬性、加入 `[ASP-UPGRADE]` 標記。

---

## 基本規則

1. `<%...%>` 和 `<%=...%>` 是**絕對禁區** — 逐字保留，不允許任何改動
2. 每個修改的 HTML 元素或區塊加 `<!-- [ASP-UPGRADE] 說明 -->`
3. 每個升級頁面必須有 `<!DOCTYPE html>` 和 `X-UA-Compatible` meta
4. 使用 HTML5 語義標籤必須引入 html5shiv

---

## 必要 `<head>` 模板

<!-- SETUP: 把下方的 {{...}} 佔位符換成你的專案實際路徑。 -->
<!-- 如果你的專案不使用 HTML5 語義標籤，可移除 <!--[if lt IE 9]--> 區段。 -->

```html
<!DOCTYPE html>
<html lang="{{SITE_LANG}}">
<!-- SETUP: {{SITE_LANG}} 換成你的語言代碼，例如 zh-TW、en、ja -->
<head>
  <meta charset="UTF-8">
  <!-- [ASP-UPGRADE] 加入 IE edge 模式與 charset 宣告 -->
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><%=pageTitle%></title>
  <!--[if lt IE 9]>
  <script src="{{HTML5SHIV_PATH}}"></script>
  <!-- SETUP: {{HTML5SHIV_PATH}} 換成你的 html5shiv 路徑，例如 /assets/js/lib/html5shiv.min.js -->
  <![endif]-->
  <link rel="stylesheet" href="{{CSS_MAIN_PATH}}">
  <!-- SETUP: {{CSS_MAIN_PATH}} 換成你的主 CSS 路徑，例如 /assets/css/main.css -->
  <script src="{{JQUERY_PATH}}"></script>
  <!-- SETUP: {{JQUERY_PATH}} 換成你的 jQuery 1.12.4 路徑，例如 /assets/js/lib/jquery-1.12.4.min.js -->
</head>
```

**設定完成後的範例：**

```html
<!DOCTYPE html>
<html lang="zh-TW">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><%=pageTitle%></title>
  <!--[if lt IE 9]>
  <script src="/assets/js/lib/html5shiv.min.js"></script>
  <![endif]-->
  <link rel="stylesheet" href="/assets/css/main.css">
  <script src="/assets/js/lib/jquery-1.12.4.min.js"></script>
</head>
```

---

## Table 版面 → Float 版面

```html
<!-- ❌ 改前：Table 作為頁面布局 -->
<table width="100%" cellpadding="0" cellspacing="0" border="0">
  <tr>
    <td width="200" valign="top" bgcolor="#f0f0f0">
      <%' 側欄 VBScript %>
    </td>
    <td valign="top">
      <%' 主內容 VBScript %>
    </td>
  </tr>
</table>

<!-- ✅ 改後 -->
<!-- [ASP-UPGRADE] table 版面改 CSS float；內部 ASP 區塊完整保留，未動一字 -->
<div class="layout clearfix">
  <div class="layout-sidebar">
    <%' 側欄 VBScript — 未動 %>
  </div>
  <div class="layout-main">
    <%' 主內容 VBScript — 未動 %>
  </div>
</div>
```

```css
/* [ASP-UPGRADE] Float 版面 CSS，取代 table layout */
.layout { zoom: 1; }
.layout:after { content: ""; display: table; clear: both; }
.layout-sidebar { float: left; width: 200px; background: #f0f0f0; }
.layout-main    { margin-left: 220px; }
```

---

## ASP 資料輸出 → 語義標記

```html
<!-- ❌ 改前 -->
<table border="1" cellpadding="4">
  <tr bgcolor="#cccccc"><th>名稱</th><th>價格</th></tr>
  <%
    Do While Not rs.EOF
  %>
  <tr>
    <td><%=rs("name")%></td>
    <td align="right"><%=FormatNumber(rs("price"),0)%></td>
  </tr>
  <%
      rs.MoveNext
    Loop
  %>
</table>

<!-- ✅ 改後 -->
<!-- [ASP-UPGRADE] Table 資料列 → div 清單；ASP loop 邏輯完整保留，未動一字 -->
<div class="data-table">
  <div class="data-row data-header clearfix">
    <span class="col-name">名稱</span>
    <span class="col-price">價格</span>
  </div>
  <%
    Do While Not rs.EOF
  %>
  <div class="data-row clearfix">
    <span class="col-name"><%=rs("name")%></span>
    <span class="col-price"><%=FormatNumber(rs("price"),0)%></span>
  </div>
  <%
      rs.MoveNext
    Loop
  %>
</div>
```

---

## Table 表單 → CSS 表單

表單升級有兩個特別重要的邊界：
1. `name` 屬性**絕對不動**
2. `<form action="..." method="...">` **絕對不動**

```html
<!-- ❌ 改前 -->
<form method="post" action="save.asp">
<table>
  <tr>
    <td align="right" width="80">名稱：</td>
    <td><input type="text" name="user_name" value="<%=Request("user_name")%>" size="20"></td>
  </tr>
  <tr>
    <td></td>
    <td><input type="submit" value="儲存"></td>
  </tr>
</table>
</form>

<!-- ✅ 改後 -->
<!-- [ASP-UPGRADE] Table 表單布局 → CSS float；name 屬性、action、ASP 值完整保留 -->
<form method="post" action="save.asp">  <!-- action 和 method 不動 -->
  <div class="form-group clearfix">
    <label class="form-label" for="user_name">名稱：</label>
    <div class="form-field">
      <!-- name="user_name" 保留原始值，不能改名 -->
      <input type="text" id="user_name" name="user_name" value="<%=Request("user_name")%>">
    </div>
  </div>
  <div class="form-group clearfix">
    <div class="form-field form-field--offset">
      <input type="submit" value="儲存" class="btn-submit">
    </div>
  </div>
</form>
```

```css
/* [ASP-UPGRADE] 表單 CSS */
.form-group { zoom: 1; margin-bottom: 12px; }
.form-group:after { content: ""; display: table; clear: both; }
.form-label  { float: left; width: 80px; line-height: 28px; text-align: right; }
.form-field  { margin-left: 92px; }
.form-field--offset { margin-left: 92px; }
.form-field input[type="text"] { width: 200px; height: 26px; padding: 0 4px; }
```

---

## VBScript 禁區操作規則

包裝用的 HTML 可以改，但不能動 VBScript 本體：

```html
<!-- ✅ 正確：加包裝，內部完全未動 -->
<!-- [ASP-UPGRADE] 加外層 ul；ASP 迴圈邏輯未動 -->
<ul class="item-list">
<%
  Dim rs, sql
  sql = "SELECT id, name FROM items WHERE active=1"
  Set rs = conn.Execute(sql)
  Do While Not rs.EOF
%>
  <li class="item">
    <a href="detail.asp?id=<%=rs("id")%>"><%=rs("name")%></a>
  </li>
<%
    rs.MoveNext
  Loop
  rs.Close : Set rs = Nothing
%>
</ul>
```

---

## 標記格式

```html
<!-- [ASP-UPGRADE] 單行說明 -->

<!-- [ASP-UPGRADE] START: 區塊說明 -->
...修改內容...
<!-- [ASP-UPGRADE] END: 區塊說明 -->

<!-- [ASP-UPGRADE] REMOVED: <font> 標籤移除，改用 CSS class .highlight -->
```

---

## HTML5 語義標籤注意事項

IE8 不原生渲染 HTML5 區塊元素，使用時必須引入 html5shiv：

```html
<!--[if lt IE 9]>
<script src="{{HTML5SHIV_PATH}}"></script>
<![endif]-->
```

**可安全使用（搭配 html5shiv）：** `<header>` `<nav>` `<main>` `<section>` `<article>` `<aside>` `<footer>`

**保守方案：** 全部改用 `<div class="...">` — 零風險，視覺效果相同

---

## 自我檢查 — HTML

### 語法合規規則

- [ ] `<!DOCTYPE html>` 在檔案最頂端
- [ ] `<meta http-equiv="X-UA-Compatible" content="IE=edge">` 在 `<head>`
- [ ] 使用 HTML5 語義標籤時有引入 html5shiv
- [ ] 未新增 `style=""` inline 屬性（已移至外部 CSS）
- [ ] CSS 使用 `:after`（單冒號），不用 `::after`（雙冒號）

### 升級範圍邊界確認（需人工確認）

- [ ] 所有 `<%...%>` 和 `<%=...%>` 完整保留，字元一字不差
- [ ] 表單欄位 `name=""` 屬性值完整保留（未被更改）
- [ ] `<form>` 的 `action` 和 `method` 屬性完整保留
- [ ] 未新增或移除任何影響後端邏輯的 HTML 結構（class / id 只新增，不改原有）
- [ ] 每個修改元素有 `[ASP-UPGRADE]` 標記
