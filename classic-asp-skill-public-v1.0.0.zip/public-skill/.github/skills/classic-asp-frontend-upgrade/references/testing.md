# 升級後測試流程 Reference

## 核心原則

**現代瀏覽器（Chrome / Edge）是主要品質標準，IE11 IE8 文件模式是向下相容驗收。**
靜態掃描確認語法合規，跨瀏覽器手動確認依序：現代瀏覽器 → IE8。

## 完整流程

```
升級執行 → 靜態掃描（語法規則 + 回歸偵測）→ 修正 ❌ → 重掃直到全 ✅
→ Chrome/Edge 手動確認 → IE11 IE8 模式確認 → 等使用者回覆「完成」→ 佈署詢問
```

---

## Step 1：執行靜態掃描

### PowerShell（Windows，推薦）

```powershell
# 掃單一檔案
.\scripts\test-compat.ps1 -File 剛升級的檔案.asp

# 掃整個專案
.\scripts\test-compat.ps1 -Dir .

# 掃指定區段（大型檔案）
.\scripts\test-compat.ps1 -File page.asp -Section "商品列表輸出"

# 跨瀏覽器手動確認完成後，將確認結果附加至報告
.\scripts\test-compat.ps1 -File page.asp -Confirm
```

### Node.js（跨平台備用）

```bash
node scripts/test-compat.js 剛升級的檔案.asp
node scripts/test-compat.js .

# 跨瀏覽器手動確認完成後，將確認結果附加至報告
node scripts/test-compat.js page.asp --confirm
```

---

## Step 2：解讀靜態掃描結果

靜態掃描分兩層規則：

| 層 | 規則類型 | 說明 |
|---|---|---|
| 語法合規規則 | IE8 相容性 | 確認沒有使用 IE8 不支援且無 fallback 的語法 |
| 回歸偵測規則 | 轉換正確性 | 確認語法轉換過程沒有遺漏邏輯或產生錯誤 |

### 通過範例

```
[product_list.asp]
  ── 語法合規規則 ──
  ✅ PASS  無 let / const
  ✅ PASS  無箭頭函數
  ✅ PASS  無 fetch API
  ✅ PASS  無 flexbox
  ✅ PASS  opacity 有 filter:alpha（雙寫）
  ✅ PASS  rgba() 有 solid 降級色（雙寫）
  ✅ PASS  有 <!DOCTYPE html>
  ✅ PASS  有 X-UA-Compatible meta
  ✅ PASS  [ASP-UPGRADE] 標記（共 18 處）
  ── 回歸偵測規則 ──
  ✅ PASS  無空函式殘留
  ✅ PASS  無重複 var 宣告
  ✅ PASS  $.ajax() 有參數

  結果：✅ 全部通過
```

→ 進入 Step 3 跨瀏覽器手動確認

### 失敗範例

```
[header.vs]
  ❌ FAIL  無箭頭函數 =>（行 23: var h = (e) => doSomething(e);）
  ❌ FAIL  opacity 需同時寫 filter:alpha（行 41: opacity: 0.8;）
  ❌ FAIL  回歸：發現空函式（行 87: var fn = function() {};）

  結果：❌ 3 個問題
```

→ **立即修正所有 ❌，重新掃描，直到全部 ✅**

---

## Step 3：失敗時修正對照

### 語法合規規則

| 錯誤 | 修正 |
|---|---|
| `let` / `const` | 改 `var` |
| 箭頭函數 `=>` | 改 `function(){ ... }`（保留主體） |
| Template literal | 改字串串接 |
| `fetch` / `Promise` | 改 `$.ajax({ url, type, data, success, error })` |
| `querySelector` | 改 jQuery `$()` |
| `display: flex` / `grid` | 改 float + clearfix |
| `calc()` | 改固定 px 或 margin offset |
| `opacity` 無 `filter:alpha` | 補 `filter: alpha(opacity=XX)` |
| `rgba()` 無 solid fallback | 在上方補 solid 色（IE8 讀不懂 rgba 就用這行） |
| 雙冒號 `::after` | 改單冒號 `:after` |
| 缺 DOCTYPE | 補 `<!DOCTYPE html>` |
| 缺 X-UA-Compatible | 補 meta 到 `<head>` |

### 回歸偵測規則

| 錯誤 | 原因 | 修正 |
|---|---|---|
| 空函式 `function(){}` | 箭頭函數轉換丟失主體 | 補回原始邏輯 |
| 重複 `var var` | 多次處理同一宣告 | 合併為單一 `var` |
| `$.ajax()` 無參數 | `fetch` 轉換不完整 | 補 url、type、success、error |
| 裸 null / undefined | template literal 轉換錯誤 | 修正串接邏輯 |
| 雙冒號偽元素殘留 | 搜尋取代不完整 | 改為單冒號 |

---

## Step 4：跨瀏覽器手動確認（靜態掃描全 ✅ 後輸出）

靜態掃描全部通過後，**逐字輸出以下確認清單，等使用者回覆才能進入佈署詢問**：

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✅ 靜態掃描通過，佈署前請完成以下手動確認：

【現代瀏覽器（Chrome / Edge）— 主要品質驗收】
  □ 頁面正常載入，無 JS 錯誤（F12 Console）
  □ 表單送出功能正常
  □ AJAX 請求正常回應（F12 Network）
  □ 排版視覺正確，符合升級目標
  □ opacity / rgba() 透明效果正確顯示
  □ border-radius / box-shadow 正確顯示

【IE11 文件模式 IE8（F12 → 文件模式 → 8）— 向下相容驗收】
  □ 頁面可正常載入
  □ 核心功能可操作（表單、互動、AJAX）
  □ 無 JS 錯誤（F12 Console）
  □ 排版不錯亂（float 佈局正確）

確認完畢後回覆「完成」，即可進行佈署紀錄。
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

> 確認順序：**先 Chrome/Edge（主），再 IE8（次）**。
> 等使用者回覆「完成」才執行下一步，不可跳過。

### Step 4.5：將確認結果附加至 MD 報告

使用者回覆「完成」後，執行以下指令將跨瀏覽器確認結果寫入 report.md：

```powershell
# PowerShell
.\scripts\test-compat.ps1 -File page.asp -Confirm
```

```bash
# Node.js
node scripts/test-compat.js page.asp --confirm
```

執行後，`reports/page.asp.report.md` 末尾會自動附加確認記錄：

```markdown
## 🌐 跨瀏覽器手動確認記錄

| 項目 | 結果 |
|---|---|
| **確認時間** | 2026-03-20 14:32:05 |
| **Chrome / Edge（主要品質驗收）** | ✅ 確認完成 |
| ↳ 頁面正常載入，無 JS 錯誤 | ✅ |
| ↳ 表單送出功能正常 | ✅ |
| ↳ AJAX 請求正常回應 | ✅ |
| ↳ 排版視覺正確，符合升級目標 | ✅ |
| ↳ opacity / rgba() 透明效果正確顯示 | ✅ |
| **IE11 文件模式 IE8（向下相容驗收）** | ✅ 確認完成 |
| ↳ 頁面可正常載入 | ✅ |
| ↳ 核心功能可操作 | ✅ |
| ↳ 無 JS 錯誤 | ✅ |
| ↳ 排版不錯亂（float 佈局正確）| ✅ |
| **整體狀態** | ✅ 靜態掃描 + 跨瀏覽器確認全部完成，可佈署 |
```

> `--confirm` 只附加，不覆蓋。每次確認都會加上時間戳，可多次執行。

---

## Step 5：測試摘要格式

```
📋 測試結果：
  掃描檔案：product_list.asp, assets/css/main.css
  語法合規：22 項 ✅  0 項 ❌
  回歸偵測：6 項 ✅   0 項 ❌
  [ASP-UPGRADE] 標記：18 處
  跨瀏覽器確認：Chrome/Edge ✅ / IE8 ✅
  狀態：全部通過，可佈署
```

---

## 靜態掃描不能取代的項目

| 項目 | 為什麼需要手動 |
|---|---|
| **Chrome/Edge 視覺品質** | opacity、rgba、border-radius 在現代瀏覽器的實際呈現 |
| **IE8 排版正確性** | float 替換後的視覺是否與升級前一致 |
| **動態互動行為** | 點擊、AJAX、表單送出需實際操作確認 |
| **VBScript 後端邏輯** | 掃描不涉及，升級也不改動 |

靜態掃描 + 跨瀏覽器手動確認 = 完整的升級品質保證。
