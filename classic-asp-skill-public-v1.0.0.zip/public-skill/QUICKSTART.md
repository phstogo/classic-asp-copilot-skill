# Classic ASP 前端升級 — 快速使用指南

## 升級目標

**現代瀏覽器（Chrome / Edge）正確運作，同時向下相容 IE8。**

現代瀏覽器是主要品質標準，IE8 是向下相容要求。透過以下三種方式達成兩者兼顧：

| 方式 | 說明 | 例子 |
|------|------|------|
| 通用基礎 | 所有瀏覽器都直接支援的語法 | float 佈局、var、function(){} |
| 雙寫 fallback | 現代語法為主，附加 IE8 fallback | opacity + filter:alpha |
| 通用替代 | IE8 無法支援，改用兼容的替代語法 | flex → float、rem → px |

---

## 安裝（一次性）

```
.github/
├── copilot-instructions.md                        ← Layer 1：永遠生效
└── skills/
    └── classic-asp-frontend-upgrade/
        ├── SKILL.md                               ← Layer 2：按需載入
        └── references/
            ├── cross-browser-javascript.md
            ├── cross-browser-css.md
            ├── html-patterns.md
            ├── testing.md
            └── deployment-logging.md
scripts/
├── test-compat.ps1                                ← 靜態掃描（Windows）
└── test-compat.js                                 ← 靜態掃描（Node.js 備用）
DEPLOYMENT.md                                      ← 佈署紀錄
QUICKSTART.md                                      ← 本檔案
```

**需求：** VS Code 1.99+、GitHub Copilot 訂閱

> 📋 **初次使用前**：請先閱讀 `SETUP.md`，填入你的專案 asset 路徑。

---

## 升級對象

| 副檔名 | 說明 |
|--------|------|
| `.asp` | ASP 頁面與 Include 檔案，全面升級 |
| `.inc` | Include 檔案，依內容判斷範圍 |

> 如果你的專案有其他副檔名（如 `.vs`、`.vbs`），請參考 `SETUP.md` 的說明加入設定。

---

## 升級邊界（每次都要確認，不能踩）

| 禁止 | 原因 |
|------|------|
| 動 `<%...%>` 任何內容 | 後端邏輯 |
| 改 HTML 結構（class/id/層級） | 後端依賴 |
| 改表單 `name` 屬性 | `Request.Form("name")` 接收 |
| 改 AJAX URL / 參數 / 回傳解析 | 只改語法，端點不動 |

---

## 每次使用流程（七步）

```
Step 1  開啟 Agent mode
Step 2  輸入升級任務
Step 3  確認程式碼
Step 4  靜態掃描（語法合規 + 回歸偵測）
Step 5  跨瀏覽器手動確認（Chrome/Edge 主，IE8 次）
Step 5.5  執行 --confirm 寫入確認報告
Step 6  佈署紀錄
```

### Step 1：開啟 Agent mode

VS Code Copilot Chat 面板右上角選 **Agent**

### Step 2：輸入升級任務

```
升級 product_list.asp 的前端，現代化優先，保持 IE8 向下相容
```
```
升級 header.inc 的前端
```
```
把 order_form.asp 的 table 布局改成 CSS float
```
```
審查 search.asp 的 JS 跨瀏覽器相容性
```

### Step 3：確認程式碼

- 有 `[ASP-UPGRADE]` 標記
- `<%...%>` 完整保留
- jQuery 1.12.4
- `opacity` 有雙寫 `filter:alpha`
- `rgba()` 上方有 solid 降級色
- 表單 `name` 屬性未改

### Step 4：靜態掃描

```powershell
.\scripts\test-compat.ps1 -File product_list.asp
.\scripts\test-compat.ps1 -Dir .
```
```bash
node scripts/test-compat.js product_list.asp
```

出現 ❌ → Copilot 立即修正，重掃直到全 ✅

### Step 5：跨瀏覽器手動確認

靜態掃描通過後 Copilot 輸出（**先現代瀏覽器，再 IE8**）：

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✅ 靜態掃描通過，佈署前請完成以下手動確認：

【現代瀏覽器（Chrome / Edge）— 主要品質驗收】
  □ 頁面正常載入，無 JS 錯誤
  □ 表單送出正常
  □ AJAX 正常回應
  □ 排版視覺正確
  □ opacity / rgba() 透明效果正確

【IE11 文件模式 IE8（F12 → 文件模式 → 8）— 向下相容驗收】
  □ 頁面正常載入
  □ 核心功能可操作
  □ 無 JS 錯誤

確認完畢後回覆「完成」。
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

### Step 5.5：將確認結果寫入 MD 報告

回覆「完成」後執行：

```powershell
.\scripts\test-compat.ps1 -File product_list.asp -Confirm
```

```bash
node scripts/test-compat.js product_list.asp --confirm
```

`reports/product_list.asp.report.md` 末尾自動附加：

```
## 🌐 跨瀏覽器手動確認記錄
確認時間：2026-03-20 14:32:05
Chrome / Edge（主要品質驗收）  ✅
IE11 文件模式 IE8（向下相容）  ✅
整體狀態：✅ 可佈署
```

### Step 6：佈署紀錄

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✅ 升級完成：product_list.asp
📋 語法合規：22 項 ✅ / 回歸偵測：6 項 ✅
🌐 Chrome/Edge ✅ / IE8 ✅
修改檔案：product_list.asp, assets/css/main.css

是否將本次變更紀錄到 DEPLOYMENT.md？
  [Y] 是 → 請提供：上線日期 / 負責人 / 備註
  [N] 否 → 略過
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## 靜態掃描規則總覽

| 類型 | 規則 |
|------|------|
| **JS 語法合規** | 無 let/const、無箭頭函數、無 template literal、無 fetch/Promise、無 querySelector、無 addEventListener、無 ES6 class/import/export、無裸 console.log、jQuery=1.12.4 |
| **CSS 語法合規** | 無 flex/grid、無 calc()、無 CSS 變數、無 rem、opacity 雙寫、rgba 雙寫、無雙冒號偽元素 |
| **HTML** | 有 DOCTYPE、有 X-UA-Compatible |
| **JS 回歸偵測** | 無空函式、無重複 var、$.ajax 有參數、無裸 null/undefined |
| **CSS 回歸偵測** | 無雙冒號偽元素、無重複 float:left |

---

## 大型檔案分段升級

### 加入分段標記

```asp
<%' [SECTION] 頁面 Head %>
<%' [SECTION] 資料列表輸出 %>
<%' [SECTION] 表單與送出 %>
<%' [SECTION] 頁尾 Script %>
```

> 標記必須放在 `</script>`、`</style>`、`%>` 之後

### 查看區段安全性

```powershell
.\scripts\test-compat.ps1 -File product_list.asp -ShowSections
```

### 升級 + 掃描指定區段

```powershell
# 升級指令（貼到 Copilot Chat）
升級 product_list.asp 的 [資料列表輸出] 區段，現代化優先，IE8 向下相容

# 掃描指定區段
.\scripts\test-compat.ps1 -File product_list.asp -Section "資料列表輸出"
```

---

## 常用 Prompt

| 任務 | Prompt |
|------|--------|
| 整頁升級 | `升級 xxx.asp，現代化優先，IE8 向下相容` |
| 只改 JS | `重寫 xxx.asp 的 JavaScript，跨瀏覽器相容` |
| 只改 CSS | `重構 xxx.asp 的 CSS，現代化優先，IE8 相容` |
| 只改布局 | `把 xxx.asp 的 table 布局改成 CSS float` |
| 相容性審查 | `審查 xxx.asp 的跨瀏覽器相容性問題` |
| 手動掃描 | `.\scripts\test-compat.ps1 -Dir .` |

---

## 重要規則

- ✅ 現代瀏覽器（Chrome/Edge）是主要品質標準
- ✅ IE8 是向下相容要求
- ✅ opacity 必須雙寫（opacity + filter:alpha）
- ✅ rgba() 必須雙寫（solid fallback 在上，rgba 在下）
- ✅ 靜態掃描全 ✅ → Chrome/Edge 確認 → IE8 確認 → --confirm 寫報告 → 佈署紀錄
- ❌ VBScript / HTML 結構 / 表單 name / AJAX URL 不能改
- ❌ 不做 .NET 轉換
