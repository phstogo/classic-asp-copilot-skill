# 安裝設定指引

複製這個 Skill 到你的專案後，有兩個地方需要依你的環境調整。其他檔案不需要修改即可使用。

---

## 需要調整的地方

### 1. `copilot-instructions.md` — 告訴 Skill 你的專案用了哪些副檔名

打開 `.github/copilot-instructions.md`，找到「專案副檔名設定」區段：

```markdown
## 專案副檔名設定

<!-- SETUP: 依你的專案調整以下副檔名說明 -->
```

**預設值（通用）：**

```
- *.asp — ASP 頁面，升級對象
- *.inc — Include 檔案，依內容判斷升級範圍
```

**常見的專案特有副檔名（依需要加入）：**

```
- *.vs  — 如果你的專案用 .vs 作為 Include 檔
- *.vbs — 如果你的專案有純 VBScript 腳本（僅套用 JS 規則）
- *.asp — 如果你的專案也用 .asp 作為 Include 檔（和主頁面相同）
```

如果你的專案只有 `.asp` 和 `.inc`，不需要修改，使用預設值即可。

---

### 2. `references/html-patterns.md` — 填入你的靜態資源路徑

打開 `.github/skills/classic-asp-frontend-upgrade/references/html-patterns.md`，找到 `<!-- SETUP -->` 標記的區段，把佔位符換成你的實際路徑：

**找到這段（`<head>` 模板）：**

```html
<script src="{{JQUERY_PATH}}"></script>
```

**換成你的實際路徑，例如：**

```html
<script src="/assets/js/lib/jquery-1.12.4.min.js"></script>
```

**同樣的，CSS 主檔路徑：**

```html
<link rel="stylesheet" href="{{CSS_PATH}}">
```

換成：

```html
<link rel="stylesheet" href="/assets/css/main.css">
```

**html5shiv 路徑（若你的系統需要支援 HTML5 語義標籤在 IE8）：**

```html
<script src="{{HTML5SHIV_PATH}}"></script>
```

換成：

```html
<script src="/assets/js/lib/html5shiv.min.js"></script>
```

如果你的系統不使用 HTML5 語義標籤，可以移除整個 `<!--[if lt IE 9]>` 區段。

---

### 3. `DEPLOYMENT.md` — 填入你的專案名稱（選填）

打開 `DEPLOYMENT.md`，把第一行標題改成你的專案名稱：

```markdown
# 上線佈署紀錄 — [你的專案名稱] 前端升級
```

---

## 不需要修改的檔案

以下檔案可以直接使用，不需要任何調整：

- `.github/copilot-instructions.md`（除了副檔名區段）
- `.github/skills/classic-asp-frontend-upgrade/SKILL.md`
- `references/cross-browser-javascript.md`
- `references/cross-browser-css.md`
- `references/testing.md`
- `references/deployment-logging.md`
- `scripts/test-compat.ps1`
- `scripts/test-compat.js`
- `QUICKSTART.md`

---

## 設定完成後，驗證安裝

在 VS Code Copilot Chat（Agent mode）輸入：

```
審查 your-first-page.asp 的跨瀏覽器相容性問題
```

如果 Copilot 回應有清楚列出 VBScript 禁區、前端問題清單、並提到 A/B/C 策略分類，代表 Skill 已正確載入。

---

## 常見問題

**Q：我的專案完全沒有 `.vs` 或 `.vbs` 副檔名，怎麼辦？**
A：不需要做任何事。`copilot-instructions.md` 已有預設處理規則，遇到不在清單裡的副檔名會依內容判斷。

**Q：我用的 jQuery 不是 1.12.4，可以嗎？**
A：Skill 強制要求 1.12.4，因為這是最後一個同時支援 IE8 和現代瀏覽器的版本。2.x 和 3.x 都放棄了 IE8 支援。如果你的系統已有其他版本的 jQuery，建議先確認是否真的需要 IE8 支援。

**Q：Node.js 和 PowerShell 腳本有什麼差別？**
A：兩者功能完全相同，只是執行環境不同。Windows 環境建議用 PowerShell（`.ps1`），跨平台或 CI/CD 環境用 Node.js（`.js`）。

**Q：可以只用這個 Skill 的一部分嗎？**
A：可以。如果你只需要 JS 升級規則，可以只放 `cross-browser-javascript.md`；如果不需要佈署記錄功能，可以移除 `deployment-logging.md` 和 `scripts/`。Layer 1 的 `copilot-instructions.md` 是最低限度的必要檔案。
