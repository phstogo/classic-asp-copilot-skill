#!/usr/bin/env node
// test-compat.js — Classic ASP 跨瀏覽器相容性掃描（現代化優先，向下相容 IE8）（Node.js 跨平台版）
// 支援：.asp .vs .inc .vbs .js .css
//
// 用法：
//   node scripts/test-compat.js page.asp
//   node scripts/test-compat.js .
//   node scripts/test-compat.js page.asp --show-sections
//   node scripts/test-compat.js page.asp --section "區段名稱"
//   node scripts/test-compat.js page.asp --confirm        # 手動測試完成後記錄確認結果
//
// 分段標記格式：<%' [SECTION] 區段名稱 %>
//
// exit code:
//   0 = 全部通過（語法合規 + 回歸）
//   1 = 語法合規失敗
//   2 = 語法合規通過，但有回歸警告

const fs   = require('fs');
const path = require('path');

const c = {
  green:   (s) => `\x1b[32m${s}\x1b[0m`,
  red:     (s) => `\x1b[31m${s}\x1b[0m`,
  yellow:  (s) => `\x1b[33m${s}\x1b[0m`,
  cyan:    (s) => `\x1b[36m${s}\x1b[0m`,
  magenta: (s) => `\x1b[35m${s}\x1b[0m`,
  dim:     (s) => `\x1b[2m${s}\x1b[0m`,
  dkYellow:(s) => `\x1b[33m\x1b[2m${s}\x1b[0m`,
};
const pass = (m) => console.log(c.green (`  ✅ PASS  ${m}`));
const fail = (m) => console.log(c.red   (`  ❌ FAIL  ${m}`));
const warn = (m) => console.log(c.yellow(`  ⚠️  WARN  ${m}`));

const REPORT_DIR = 'reports';
// ── --confirm 模式：將跨瀏覽器手動確認結果附加至現有報告 ─────────────────────
function runConfirm(filePath) {
  const safeName = path.basename(filePath).replace(/[/\\:*?"<>|]/g, '_');
  const rptPath  = path.join(REPORT_DIR, `${safeName}.report.md`);
  if (!fs.existsSync(rptPath)) {
    console.error(`\n  ❌ 找不到報告：${rptPath}`);
    console.error(`     請先執行掃描：node scripts/test-compat.js ${filePath}`);
    process.exit(1);
  }
  const now = new Date().toLocaleString('zh-TW', { hour12: false });
  const section = `
---

## 🌐 跨瀏覽器手動確認記錄

| 項目 | 結果 |
|---|---|
| **確認時間** | ${now} |
| **Chrome / Edge（主要品質驗收）** | ✅ 確認完成 |
| ↳ 頁面正常載入，無 JS 錯誤 | ✅ |
| ↳ 表單送出功能正常 | ✅ |
| ↳ AJAX 請求正常回應 | ✅ |
| ↳ 排版視覺正確，符合升級目標 | ✅ |
| ↳ opacity / rgba() 透明效果正確顯示 | ✅ |
| **IE11 文件模式 IE8（向下相容驗收）** | ✅ 確認完成 |
| ↳ 頁面可正常載入 | ✅ |
| ↳ 核心功能可操作 | ✅ |
| ↳ 無 JS 錯誤 | ✅ |
| ↳ 排版不錯亂（float 佈局正確）| ✅ |
| **整體狀態** | ✅ 靜態掃描 + 跨瀏覽器確認全部完成，可佈署 |

> 由 test-compat.js --confirm 自動附加
`;
  fs.appendFileSync(rptPath, section, 'utf8');
  console.log('');
  console.log('  ✅ 跨瀏覽器確認結果已附加至報告');
  console.log(`     ${rptPath}`);
  console.log('');
  console.log('  下一步：');
  console.log('    詢問是否將本次升級記錄到 DEPLOYMENT.md');
  process.exit(0);
}


if (!fs.existsSync(REPORT_DIR)) fs.mkdirSync(REPORT_DIR);

// ── IE8 規則定義 ──────────────────────────────────────────
const JS_RULES = [
  { re: /\b(let|const)\b\s+\w+/,              msg: '禁用 let / const，改用 var' },
  { re: /=>\s*[{(]|=>\s*\w/,                  msg: '禁用箭頭函數 =>，改用 function(){}' },
  { re: /`[^`]*\$\{/,                          msg: '禁用 template literal，改用字串串接' },
  { re: /\.addEventListener\s*\(/,             msg: '禁用 addEventListener，改用 jQuery .on()' },
  { re: /\bfetch\s*\(/,                        msg: '禁用 fetch API，改用 $.ajax()' },
  { re: /\bPromise\s*[.(]/,                   msg: '禁用 Promise，改用 $.ajax()' },
  { re: /\.querySelector(All)?\s*\(/,          msg: '禁用 querySelector，改用 jQuery $()' },
  { re: /\bclass\s+\w+[\s{]/,                 msg: '禁用 ES6 class，改用 prototype 模式' },
  { re: /\bimport\s+.+from\s+['"]/,           msg: '禁用 ES6 import' },
  { re: /\bexport\s+(default\s+)?/,            msg: '禁用 ES6 export' },
  { re: /console\.log\s*\(/, exclude: /window\.console/, msg: 'console.log 需加 if(window.console) 保護' },
  { re: /jquery[-_.](([2-9])|([1-9]\d))\./i, msg: '偵測到 jQuery 2.x+，必須用 1.12.4' },
];
const CSS_RULES = [
  { re: /display\s*:\s*flex/,  msg: '禁用 flexbox，改用 float + clearfix' },
  { re: /display\s*:\s*grid/,  msg: '禁用 CSS grid，改用 float' },
  { re: /grid-template/,       msg: '禁用 grid-template' },
  { re: /:\s*calc\s*\(/,       msg: '禁用 calc()，改用固定 px 或 margin offset' },
  { re: /var\s*\(--/,          msg: '禁用 CSS 自訂變數 var(--)' },
  { re: /:\s*[\d.]+rem\b/,    msg: '禁用 rem 單位，改用 px' },
];
const HTML_RULES = [
  { re: /<!DOCTYPE\s+html>/i, msg: '<!DOCTYPE html>',      invert: true },
  { re: /X-UA-Compatible/,    msg: 'X-UA-Compatible meta', invert: true },
];

// ── 回歸規則定義（偵測升級轉換常見錯誤）────────────────────
// helpMsg 附在報告與終端機作修正建議
const REGRESSION_JS_RULES = [
  {
    re:      /function\s*\(\s*\)\s*\{\s*\}/,
    msg:     '回歸：發現空函式，可能是箭頭函數轉換不完整',
    helpMsg: '原始箭頭函數有函式主體，轉換為 function(){} 時應保留主體邏輯',
  },
  {
    re:      /\bvar\s+var\s+/,
    msg:     '回歸：重複的 var 宣告（var var），可能是多次處理同一行',
    helpMsg: '合併為單一 var 宣告',
  },
  {
    re:      /\$\.ajax\s*\(\s*\)/,
    msg:     '回歸：$.ajax() 呼叫無參數，可能是 fetch 轉換不完整',
    helpMsg: '補回 url、method、data、success、error 等必要參數',
  },
  {
    re:      /\bnull\b|\bundefined\b/,
    msg:     '回歸：發現裸 null 或 undefined，可能是 template literal 轉換錯誤',
    helpMsg: '確認字串串接邏輯正確，null/undefined 不應出現在拼接後的字串裡',
  },
];
const REGRESSION_CSS_RULES = [
  {
    re:      /::\s*after|::\s*before/,
    msg:     '回歸：發現雙冒號偽元素 ::after/::before，IE8 只支援單冒號',
    helpMsg: '改為 :after / :before（單冒號），現代瀏覽器向下相容',
  },
  {
    re:      /float\s*:\s*left[^}]*float\s*:\s*left/s,
    msg:     '回歸：同一規則集有重複 float:left，可能是 flex 轉換殘留',
    helpMsg: '移除多餘的 float 宣告，每個規則集保留一個即可',
  },
];

const ASP_LIKE = new Set(['.asp', '.vs', '.inc']);
const VBS_ONLY = new Set(['.vbs']);
const ALL_EXT  = new Set([...ASP_LIKE, ...VBS_ONLY, '.js', '.css']);
const SKIP     = ['jquery-', 'jquery.', 'html5shiv', 'json2', 'pie', 'reports'];

function getFiles(target) {
  const stat = fs.statSync(target);
  if (stat.isFile()) return [target];
  const result = [];
  function walk(dir) {
    fs.readdirSync(dir).forEach(name => {
      const full = path.join(dir, name);
      if (SKIP.some(s => name.toLowerCase().includes(s))) return;
      const s = fs.statSync(full);
      if (s.isDirectory()) return walk(full);
      if (ALL_EXT.has(path.extname(name).toLowerCase())) result.push(full);
    });
  }
  walk(target);
  return result;
}

// ── 解析 [SECTION] 標記 ──────────────────────────────────
function getSections(lines) {
  const sections = [];
  const pat = /'\s*\[SECTION\]\s*(.+?)\s*%>/;
  let cur = null;
  lines.forEach((line, i) => {
    const m = line.match(pat);
    if (m) {
      if (cur) { cur.endLine = i; sections.push(cur); }
      cur = { name: m[1].trim(), startLine: i + 1, endLine: lines.length };
    }
  });
  if (cur) { cur.endLine = lines.length; sections.push(cur); }
  return sections;
}

// ── 邊界安全性分析 ────────────────────────────────────────
function getBoundaryRisk(lines, lineNum1Based) {
  const idx = lineNum1Based - 1;
  let inScript   = false;
  let inStyle    = false;
  let inVbBlock  = false;
  let braceDepth = 0;
  let parenDepth = 0;

  for (let i = 0; i < idx; i++) {
    const l = lines[i];

    if (/<%/.test(l) && !/'.*\[SECTION\]/.test(l)) {
      const opens  = (l.match(/<%/g)  || []).length;
      const closes = (l.match(/%>/g)  || []).length;
      if (opens > closes) inVbBlock = true;
      else if (closes >= opens && inVbBlock) inVbBlock = false;
    } else if (/%>/.test(l) && inVbBlock) {
      inVbBlock = false;
    }

    if (/<script[\s>]/.test(l) && !/<\/script>/.test(l)) { inScript = true; }
    if (/<\/script>/.test(l))  { inScript = false; braceDepth = 0; }

    if (/<style[\s>]/.test(l) && !/<\/style>/.test(l)) { inStyle = true; }
    if (/<\/style>/.test(l))   { inStyle = false; }

    if (inScript) {
      braceDepth += (l.match(/\{/g) || []).length;
      braceDepth -= (l.match(/\}/g) || []).length;
      if (braceDepth < 0) braceDepth = 0;
    }

    parenDepth += (l.match(/\(/g) || []).length;
    parenDepth -= (l.match(/\)/g) || []).length;
    if (parenDepth < 0) parenDepth = 0;
  }

  if (inVbBlock)                  return '在多行 VBScript <% ... %> 區塊內';
  if (inScript && braceDepth > 0) return `在 <script> 區塊的函式/物件內（{ } 深度 ${braceDepth}）`;
  if (inScript)                   return '在 <script> ... </script> 區塊內';
  if (inStyle)                    return '在 <style> ... </style> 區塊內';
  if (parenDepth > 0)             return `在未關閉的括號內（深度 ${parenDepth}）`;
  return '';
}

function findSafeBoundary(lines, lineNum1Based) {
  for (let i = lineNum1Based - 2; i >= 0; i--) {
    const l = lines[i];
    if (/<\/script>/.test(l) || /<\/style>/.test(l) ||
        /%>/.test(l)          || /<\/div>/.test(l)   ||
        /<\/table>/.test(l)   || /<\/form>/.test(l)) {
      return i + 2;
    }
  }
  return -1;
}

// ── 快速計算區段問題數 ────────────────────────────────────
function countSectionIssues(sLines, ext) {
  let n = 0;
  const rules = [];
  if (ASP_LIKE.has(ext) || VBS_ONLY.has(ext) || ext === '.js') rules.push(...JS_RULES);
  if (ASP_LIKE.has(ext) || ext === '.css') rules.push(...CSS_RULES);
  rules.forEach(rule => {
    const hit = sLines.some(l => {
      if ((ASP_LIKE.has(ext) || VBS_ONLY.has(ext)) && /<%/.test(l)) return false;
      if (!rule.re.test(l)) return false;
      if (rule.exclude && rule.exclude.test(l)) return false;
      return true;
    });
    if (hit) n++;
  });
  return n;
}

// ── ShowSections 模式 ─────────────────────────────────────
function showSections(filePath) {
  const ext      = path.extname(filePath).toLowerCase();
  const lines    = fs.readFileSync(filePath, 'utf8').split('\n');
  const sections = getSections(lines);
  const base     = path.basename(filePath);

  console.log(c.cyan(`\n[${base}] — 區段清單（共 ${lines.length} 行）`));

  if (sections.length === 0) {
    warn('此檔案沒有 [SECTION] 標記');
    console.log('');
    console.log(c.yellow('  建議在超過 800 行的大型檔案中加入分段標記，例如：'));
    console.log(c.yellow("  <%' [SECTION] 頁面 Head %>"));
    console.log(c.yellow("  <%' [SECTION] 商品列表輸出 %>"));
    console.log(c.yellow("  <%' [SECTION] 表單與送出 %>"));
    console.log(c.yellow("  <%' [SECTION] 頁尾 Script %>"));
    console.log('');
    console.log(c.yellow('  ⚠️  標記必須放在 </script> </style> %> 之後，下一個區塊開始之前'));
    return;
  }

  const riskMap  = {};
  const safeMap  = {};
  let   hasDanger = false;
  sections.forEach(s => {
    const risk = getBoundaryRisk(lines, s.startLine);
    if (risk) {
      riskMap[s.name] = risk;
      hasDanger = true;
      const at = findSafeBoundary(lines, s.startLine);
      if (at > 0) safeMap[s.name] = at;
    }
  });

  console.log('');
  console.log(c.cyan('  #    行號範圍                           狀態         區段名稱'));
  console.log(c.dim ('  --   --------                           ----         --------'));

  let idx = 1;
  sections.forEach(s => {
    const lineCount = s.endLine - s.startLine + 1;
    const range     = `行 ${s.startLine}–${s.endLine}（${lineCount} 行）`;
    const padRange  = range.padEnd(38);

    if (riskMap[s.name]) {
      console.log(c.yellow(`  #${idx}  ${padRange} ⚠️ 邊界危險  ${s.name}`));
      console.log(c.red   (`       ↑ 標記位於：${riskMap[s.name]}`));
      if (safeMap[s.name]) {
        console.log(c.dkYellow(`       💡 建議移到行 ${safeMap[s.name]} 之後（最近的安全邊界）`));
      } else {
        console.log(c.dkYellow('       💡 請手動移到最近的 </script> </style> %> 或 </div> 之後'));
      }
    } else {
      const sLines = lines.slice(s.startLine - 1, s.endLine);
      const n      = countSectionIssues(sLines, ext);
      const icon   = n === 0 ? '✅ 安全    ' : `❌ 安全(${n})  `;
      console.log(`  #${idx}  ${padRange} ${icon} ${s.name}`);
    }
    idx++;
  });

  console.log('');
  if (hasDanger) {
    console.log(c.yellow('  ⚠️  請先修正上方標記位置，再進行 Copilot 升級。'));
    console.log(c.red   ('  邊界危險的區段，Copilot 看到不完整的程式碼，有誤改後端邏輯的風險。'));
  } else {
    console.log(c.green('  ✅ 所有分段標記位置安全，可進行升級。'));
    console.log('');
    console.log(c.cyan('  Copilot 升級指令（僅列出有問題的區段）：'));
    sections.forEach(s => {
      const sLines = lines.slice(s.startLine - 1, s.endLine);
      const n      = countSectionIssues(sLines, ext);
      if (n > 0) {
        console.log(c.dim(`  升級 ${base} 的 [${s.name}] 區段（行 ${s.startLine}–${s.endLine}），跨瀏覽器相容`));
      }
    });
    console.log('');
    console.log(c.cyan  ('  掃描指定區段：'));
    console.log(c.yellow(`  node scripts/test-compat.js ${base} --section "區段名稱"`));
  }
}

// ── 掃描單一檔案 ──────────────────────────────────────────
function testFile(filePath, sectionName = '') {
  const ext       = path.extname(filePath).toLowerCase();
  const raw       = fs.readFileSync(filePath, 'utf8');
  const allLines  = raw.split('\n');
  const isAspLike = ASP_LIKE.has(ext);
  const isServer  = (l) => (ASP_LIKE.has(ext) || VBS_ONLY.has(ext)) && /<%/.test(l);

  let scanLines       = allLines;
  let lineOffset      = 0;
  let rangeLabel      = `全部 ${allLines.length} 行`;
  let boundaryWarning = '';

  if (sectionName) {
    const sections = getSections(allLines);
    const found    = sections.find(s => s.name === sectionName);
    if (!found) {
      console.log(c.red  (`  ❌ 找不到區段：${sectionName}`));
      console.log(c.yellow('  請先執行 --show-sections 查看可用區段'));
      return { issues: 0, regrIssues: 0, passCount: 0, regrPass: 0, markCount: 0, rptPath: '' };
    }

    const risk = getBoundaryRisk(allLines, found.startLine);
    if (risk) {
      boundaryWarning = risk;
      const safeAt = findSafeBoundary(allLines, found.startLine);
      console.log('');
      console.log(c.yellow(`  ⚠️  邊界警告：[${sectionName}] 的分段標記位於「${risk}」`));
      if (safeAt > 0) console.log(c.yellow(`  💡 建議將標記移到行 ${safeAt} 之後再進行升級`));
      console.log(c.red  (`  ⛔ 繼續掃描，但使用此區段讓 Copilot 升級有誤改後端邏輯的風險`));
      console.log('');
    }

    lineOffset = found.startLine - 1;
    scanLines  = allLines.slice(lineOffset, found.endLine);
    rangeLabel = `[${sectionName}] 行 ${found.startLine}–${found.endLine}，共 ${scanLines.length} 行`;
  }

  let issues = 0, passCount = 0, regrIssues = 0, regrPass = 0;
  const rPass = [], rFail = [], rWarn = [], rRPass = [], rRFail = [], rDet = {}, rHelp = {};
  const base = path.basename(filePath);

  const addPass  = (msg) => { pass(msg); rPass.push(msg); passCount++; };
  const addFail  = (msg, hits = []) => {
    fail(msg);
    hits.forEach(h => console.log(c.dim(`    ${h}`)));
    rFail.push(msg);
    if (hits.length) rDet[msg] = hits;
    issues++;
  };
  const addWarn  = (msg) => { warn(msg); rWarn.push(msg); };
  const addRPass = (msg) => { pass(msg); rRPass.push(msg); regrPass++; };
  const addRFail = (msg, hits = [], helpMsg = '') => {
    fail(msg);
    hits.forEach(h => console.log(c.dim(`    ${h}`)));
    if (helpMsg) console.log(c.dkYellow(`    💡 ${helpMsg}`));
    rRFail.push(msg);
    if (hits.length) rDet[msg] = hits;
    if (helpMsg)     rHelp[msg] = helpMsg;
    regrIssues++;
  };

  console.log(c.cyan(`\n[${base}]  (${rangeLabel})`));

  // ── IE8 規則 ────────────────────────────────────────────
  console.log(c.cyan('  ── 語法合規規則（跨瀏覽器） ──'));

  const ie8Rules = [];
  if (ASP_LIKE.has(ext) || VBS_ONLY.has(ext) || ext === '.js') ie8Rules.push(...JS_RULES);
  if (ASP_LIKE.has(ext) || ext === '.css') ie8Rules.push(...CSS_RULES);

  ie8Rules.forEach(rule => {
    const hits = scanLines
      .map((l, i) => ({ l, i }))
      .filter(({ l }) => {
        if (isServer(l)) return false;
        if (!rule.re.test(l)) return false;
        if (rule.exclude && rule.exclude.test(l)) return false;
        return true;
      })
      .map(({ l, i }) => `行 ${i + 1 + lineOffset}： ${l.trim()}`);
    hits.length > 0 ? addFail(rule.msg, hits) : addPass(rule.msg);
  });

  // opacity 雙寫
  if (ASP_LIKE.has(ext) || ext === '.css') {
    const sc = scanLines.join('\n');
    if (/opacity\s*:/.test(sc) && !/filter\s*:\s*alpha\s*\(opacity/.test(sc)) {
      addFail('opacity 需同時加 filter:alpha(opacity=XX)');
    } else if (/opacity\s*:/.test(sc)) {
      addPass('opacity 有伴隨 filter:alpha');
    }
  }

  // rgba fallback
  if (ASP_LIKE.has(ext) || ext === '.css') {
    if (/rgba\s*\(/.test(scanLines.join('\n'))) {
      let hasRgbaFallback = false;
      for (let i = 1; i < scanLines.length; i++) {
        if (/rgba\s*\(/.test(scanLines[i])) {
          if (/#[0-9a-fA-F]{3,6}|background:\s*[a-z]+/.test(scanLines[i - 1])) {
            hasRgbaFallback = true; break;
          }
        }
      }
      if (!hasRgbaFallback) {
        addFail('rgba() 需在上方加 solid 降級色');
      } else {
        addPass('rgba() 有 solid 降級色');
      }
    }
  }

  // HTML 規則（全檔）
  if (isAspLike && !sectionName) {
    HTML_RULES.forEach(rule => {
      const found = rule.re.test(raw);
      if (rule.invert) {
        found ? addPass(`有 ${rule.msg}`) : addFail(`缺少 ${rule.msg}`);
      }
    });
  }

  // [ASP-UPGRADE] 標記
  const markCount = (scanLines.join('\n').match(/\[ASP-UPGRADE\]/g) || []).length;
  if (markCount > 0) {
    addPass(`[ASP-UPGRADE] 標記存在（共 ${markCount} 處）`);
  } else {
    addWarn('[ASP-UPGRADE] 找不到升級標記，請確認是否已完成升級');
  }

  // ── 回歸規則 ────────────────────────────────────────────
  console.log(c.cyan('  ── 回歸偵測規則（升級轉換錯誤）──'));

  const regrRules = [];
  if (ASP_LIKE.has(ext) || VBS_ONLY.has(ext) || ext === '.js') regrRules.push(...REGRESSION_JS_RULES);
  if (ASP_LIKE.has(ext) || ext === '.css') regrRules.push(...REGRESSION_CSS_RULES);

  const fullBlock = scanLines.join('\n');

  regrRules.forEach(rule => {
    // 多行旗標規則（/s flag）用全文比對；其餘逐行
    let hits = [];
    if (rule.re.flags.includes('s') || rule.msg.includes('CSS')) {
      if (rule.re.test(fullBlock)) hits = ['（全文比對命中）'];
    } else {
      hits = scanLines
        .map((l, i) => ({ l, i }))
        .filter(({ l }) => !isServer(l) && rule.re.test(l))
        .map(({ l, i }) => `行 ${i + 1 + lineOffset}： ${l.trim()}`);
    }
    if (hits.length > 0) {
      addRFail(rule.msg, hits, rule.helpMsg || '');
    } else {
      addRPass(rule.msg);
    }
  });

  // ── Markdown 報告 ────────────────────────────────────
  const now      = new Date().toLocaleString('zh-TW');
  const ie8Stat  = issues === 0     ? '✅ 通過' : `❌ 失敗 (${issues} 項)`;
  const regrStat = regrIssues === 0 ? '✅ 通過' : `⚠️ 發現 ${regrIssues} 項`;
  const overall  = issues === 0 && regrIssues === 0 ? '✅ 全部通過' : '❌ 需修正';

  let safeName = base.replace('.', '_');
  if (sectionName) safeName += '_' + sectionName.replace(/\s/g, '_');
  const rptPath = path.join(REPORT_DIR, `${safeName}.report.md`);

  const md = [];
  md.push('# 跨瀏覽器相容性測試報告', '');
  md.push('| 項目 | 內容 |', '|---|---|');
  md.push(`| **檔案名稱** | \`${base}\` |`);
  md.push(`| **完整路徑** | \`${path.resolve(filePath)}\` |`);
  md.push(`| **掃描範圍** | ${rangeLabel} |`);
  md.push(`| **副檔名** | ${ext} |`);
  md.push(`| **掃描時間** | ${now} |`);
  if (boundaryWarning) md.push(`| **⚠️ 邊界警告** | 標記位於：${boundaryWarning} |`);
  md.push(`| **語法合規** | ${ie8Stat} |`);
  md.push(`| **回歸偵測** | ${regrStat} |`);
  md.push(`| **整體結果** | ${overall} |`);
  md.push(`| **語法合規通過** | ${passCount} 項 ✅ |`);
  md.push(`| **語法合規失敗** | ${issues} 項 ❌ |`);
  md.push(`| **回歸通過** | ${regrPass} 項 ✅ |`);
  md.push(`| **回歸失敗** | ${regrIssues} 項 ⚠️ |`);
  md.push(`| **[ASP-UPGRADE] 標記** | ${markCount} 處 |`, '');

  if (boundaryWarning) {
    md.push('## ⚠️ 邊界安全警告', '');
    md.push(`此區段的分段標記位於危險位置：**${boundaryWarning}**`, '');
    md.push(`請將 \`<%' [SECTION] ${sectionName} %>\` 移到最近的 \`</script>\`、\`</style>\`、\`%>\` 或 \`</div>\` 之後，`);
    md.push('再使用此區段進行 Copilot 升級，否則有誤改後端邏輯的風險。', '');
  }

  if (rFail.length > 0) {
    md.push('## ❌ 語法合規失敗（需修正）', '');
    rFail.forEach(msg => {
      md.push(`### ${msg}`, '');
      if (rDet[msg]) { md.push('發現位置：', '```'); rDet[msg].forEach(l => md.push(l)); md.push('```'); }
      md.push('');
    });
  }

  if (rRFail.length > 0) {
    md.push('## ⚠️ 回歸偵測失敗（轉換錯誤，需確認）', '');
    md.push('> 回歸規則偵測升級轉換過程中常見的錯誤模式。發現時請確認原始邏輯是否完整保留。', '');
    rRFail.forEach(msg => {
      md.push(`### ${msg}`, '');
      if (rHelp[msg]) { md.push(`💡 **修正建議**：${rHelp[msg]}`, ''); }
      if (rDet[msg])  { md.push('發現位置：', '```'); rDet[msg].forEach(l => md.push(l)); md.push('```'); }
      md.push('');
    });
  }

  if (rWarn.length > 0) {
    md.push('## ⚠️ 警告項目', '');
    rWarn.forEach(msg => md.push(`- ${msg}`));
    md.push('');
  }

  if (rPass.length > 0) {
    md.push('## ✅ 語法合規通過', '');
    rPass.forEach(msg => md.push(`- ${msg}`));
    md.push('');
  }

  if (rRPass.length > 0) {
    md.push('## ✅ 回歸偵測通過', '');
    rRPass.forEach(msg => md.push(`- ${msg}`));
    md.push('');
  }

  // 跨瀏覽器確認清單（全部通過才附加）
  if (issues === 0 && regrIssues === 0) {
    md.push('## 🌐 跨瀏覽器確認清單', '');
    md.push('靜態掃描通過，佈署前請手動確認以下項目：', '');
    md.push('**Chrome / Edge（現代瀏覽器）— 主要品質驗收**');
    md.push('- [ ] 頁面正常載入，無 JS 錯誤（F12 Console）');
    md.push('- [ ] 表單送出功能正常');
    md.push('- [ ] AJAX 請求正常回應（F12 Network）');
    md.push('- [ ] 排版視覺正確，符合升級目標');
    md.push('- [ ] opacity / rgba() 透明效果正確顯示', '');
    md.push('**IE11 文件模式 IE8（F12 → 文件模式 → 8）— 向下相容驗收**');
    md.push('- [ ] 頁面可正常載入');
    md.push('- [ ] 核心功能可操作（表單、互動、AJAX）');
    md.push('- [ ] 無 JS 錯誤（F12 Console）');
    md.push('- [ ] 排版不錯亂（float 佈局正確）', '');
  }

  if (sectionName) {
    md.push('## 📋 下一步', '');
    const allPass = issues === 0 && regrIssues === 0;
    md.push(allPass ? '此區段通過，執行以下指令查看其他區段狀態：' : '修正後重新掃描，或查看所有區段狀態：');
    md.push('```bash', `node scripts/test-compat.js ${base} --show-sections`, '```', '');
  }

  md.push('---', '');
  const totalFail = issues + regrIssues;
  md.push(totalFail === 0
    ? '> ✅ 語法合規與回歸偵測全部通過。請依序完成 Chrome/Edge（主要品質）與 IE8（向下相容）手動確認後再佈署。'
    : `> ❌ 請修正上述 ${totalFail} 個問題後重新掃描。`
  );

  fs.writeFileSync(rptPath, md.join('\n'), 'utf8');
  console.log(c.cyan(`  📄 報告：${rptPath}`));

  return { issues, regrIssues, passCount, regrPass, markCount, rptPath, name: base };
}

// ── 主執行 ────────────────────────────────────────────────
const args        = process.argv.slice(2);
const target      = args.find(a => !a.startsWith('--')) || '.';
const showSec     = args.includes('--show-sections');
const doConfirm   = args.includes('--confirm');
const secIdx      = args.indexOf('--section');
const sectionName = secIdx !== -1 ? args[secIdx + 1] : '';
const modeStr     = showSec ? '顯示區段清單（含邊界安全檢查）' : sectionName ? `區段掃描 [${sectionName}]` : '全檔掃描';

// --confirm 模式入口
if (doConfirm) {
  const confirmFile = args.find(a => !a.startsWith('--'));
  if (!confirmFile) {
    console.error('  ❌ --confirm 需指定檔案，例如：node scripts/test-compat.js page.asp --confirm');
    process.exit(1);
  }
  runConfirm(confirmFile);
}

if (!fs.existsSync(target)) { console.error(c.red(`找不到：${target}`)); process.exit(1); }

console.log(c.cyan  ('\n==================================================='));
console.log(c.cyan  ('  Classic ASP 跨瀏覽器相容性掃描（現代化優先，向下相容 IE8）'));
console.log(c.magenta(`  模式：${modeStr}`));
console.log(c.cyan  (`  ${new Date().toLocaleString('zh-TW')}`));
console.log(c.cyan  ('==================================================='));

const files = getFiles(target);
if (files.length === 0) { console.log(c.yellow('找不到可掃描的檔案')); process.exit(1); }

if (showSec) { files.forEach(f => showSections(f)); process.exit(0); }

let totalIssues    = 0;
let totalRegrIssues = 0;
const results = [];

files.forEach(f => {
  const r = testFile(f, sectionName);
  totalIssues     += r.issues;
  totalRegrIssues += r.regrIssues;
  results.push(r);
});

// ── 總結報告 ─────────────────────────────────────────────
const now         = new Date().toLocaleString('zh-TW');
const summaryPath = path.join(REPORT_DIR, '_summary.report.md');
const sm = [];
sm.push('# 跨瀏覽器相容性掃描 — 總結報告', '');
sm.push('| 項目 | 內容 |', '|---|---|');
sm.push(`| **掃描時間** | ${now} |`);
sm.push(`| **掃描模式** | ${modeStr} |`);
sm.push(`| **掃描檔案數** | ${files.length} |`);
sm.push(`| **語法合規問題數** | ${totalIssues} |`);
sm.push(`| **回歸問題數** | ${totalRegrIssues} |`);

let finalStatus;
if      (totalIssues > 0)                    finalStatus = '❌ 語法合規失敗';
else if (totalRegrIssues > 0)                finalStatus = '⚠️ 回歸偵測警告';
else                                          finalStatus = '✅ 全部通過';
sm.push(`| **整體結果** | ${finalStatus} |`, '');

sm.push('## 各檔案結果', '');
sm.push('| 檔案 | 結果 | 語法合規 | 合規失敗 | 回歸警告 | 標記數 | 報告 |');
sm.push('|---|---|---|---|---|---|---|');
results.forEach(r => {
  const s = r.issues > 0 ? '❌ 失敗' : r.regrIssues > 0 ? '⚠️ 回歸' : '✅ 通過';
  sm.push(`| \`${r.name}\` | ${s} | ${r.passCount} ✅ | ${r.issues} ❌ | ${r.regrIssues} ⚠️ | ${r.markCount} 處 | [查看](./${path.basename(r.rptPath)}) |`);
});
sm.push('');

// 跨瀏覽器清單（全部通過才附加）
if (totalIssues === 0 && totalRegrIssues === 0) {
  sm.push('## 🌐 跨瀏覽器確認清單', '');
  sm.push('靜態掃描全部通過，佈署前請手動確認：', '');
  sm.push('**Chrome / Edge（現代瀏覽器）— 主要品質驗收**');
  sm.push('- [ ] 所有升級頁面正常載入，無 JS 錯誤（F12 Console）');
  sm.push('- [ ] 表單送出功能正常');
  sm.push('- [ ] AJAX 請求正常回應（F12 Network）');
  sm.push('- [ ] 排版視覺正確，符合升級目標');
  sm.push('- [ ] opacity / rgba() 透明效果正確顯示', '');
  sm.push('**IE11 文件模式 IE8（F12 → 文件模式 → 8）— 向下相容驗收**');
  sm.push('- [ ] 頁面可正常載入');
  sm.push('- [ ] 核心功能可操作（表單、互動、AJAX）');
  sm.push('- [ ] 無 JS 錯誤（F12 Console）');
  sm.push('- [ ] 排版不錯亂（float 佈局正確）', '');
}

sm.push('---', '');
if (totalIssues === 0 && totalRegrIssues === 0) {
  sm.push('> ✅ 所有檔案通過靜態掃描與回歸偵測，請完成跨瀏覽器手動確認後佈署。');
} else if (totalIssues > 0) {
  sm.push(`> ❌ 請點擊各檔案報告連結，修正 ${totalIssues} 個語法合規失敗項目後重新掃描。`);
} else {
  sm.push(`> ⚠️ IE8 規則通過，但有 ${totalRegrIssues} 個回歸警告。請確認轉換邏輯完整後再佈署。`);
}

fs.writeFileSync(summaryPath, sm.join('\n'), 'utf8');

// ── 終端機最終輸出 ────────────────────────────────────────
console.log(c.cyan(`\n===================================================`));
console.log(c.cyan(`  掃描完成：${files.length} 個檔案`));
console.log(c.cyan(`  總結報告：${summaryPath}`));

if (totalIssues === 0 && totalRegrIssues === 0) {
  console.log(c.green('  結果：✅ 全部通過（語法合規 + 回歸偵測）'));
  console.log('');
  console.log(c.yellow('  ⚠️  靜態掃描通過，佈署前請完成以下手動確認：'));
  console.log('');
  console.log(c.cyan  ('  【Chrome / Edge（現代瀏覽器）— 主要品質驗收】'));
  console.log('    □ 頁面正常載入，無 JS 錯誤（F12 Console）');
  console.log('    □ 表單送出功能正常');
  console.log('    □ AJAX 請求正常回應（F12 Network）');
  console.log('    □ 排版視覺正確，符合升級目標');
  console.log('    □ opacity / rgba() 透明效果正確顯示');
  console.log('');
  console.log(c.cyan  ('  【IE11 文件模式 IE8（F12 → 文件模式 → 8）— 向下相容驗收】'));
  console.log('    □ 頁面可正常載入');
  console.log('    □ 核心功能可操作（表單、互動、AJAX）');
  console.log('    □ 無 JS 錯誤（F12 Console）');
  console.log('    □ 排版不錯亂（float 佈局正確）');
  console.log('');
  process.exit(0);
} else if (totalIssues > 0) {
  console.log(c.red(`  結果：❌ 語法合規 ${totalIssues} 個問題，回歸偵測 ${totalRegrIssues} 個警告`));
  process.exit(1);
} else {
  console.log(c.yellow(`  結果：⚠️ 語法合規通過，但有 ${totalRegrIssues} 個回歸警告，請確認`));
  process.exit(2);
}
