# test-compat.ps1
# Classic ASP 前端升級 — 跨瀏覽器相容性掃描（現代化優先，向下相容 IE8）
# 支援副檔名：.asp .vs .inc .vbs .js .css
# 每個檔案掃描完自動產生 reports\<filename>.report.md
# 跨瀏覽器手動確認後執行 -Confirm 將結果附加至報告
#
# 用法：
#   .\scripts\test-compat.ps1 -File page.asp
#   .\scripts\test-compat.ps1 -Dir .
#   .\scripts\test-compat.ps1 -File page.asp -ShowSections
#   .\scripts\test-compat.ps1 -File page.asp -Section "商品列表"
#   .\scripts\test-compat.ps1 -File page.asp -Confirm       # 手動測試完成後記錄確認結果
#
# 分段標記格式：<%' [SECTION] 區段名稱 %>

param(
    [string]$File         = "",
    [string]$Dir          = "",
    [switch]$ShowSections,
    [string]$Section      = "",
    [switch]$Confirm
)

$ReportDir = "reports"
if (-not (Test-Path $ReportDir)) { New-Item -ItemType Directory -Path $ReportDir | Out-Null }
# ── -Confirm 模式：將跨瀏覽器手動確認結果附加到現有報告 ────────────────────────
if ($Confirm) {
    if ($File -eq "") {
        Write-Host "  ❌ -Confirm 需搭配 -File 指定檔案" -ForegroundColor Red
        Write-Host "     範例：.\scripts\test-compat.ps1 -File page.asp -Confirm"
        exit 1
    }
    $safeName  = ($File -replace "[\\/:*?`"<>|]", "_")
    $rptPath   = Join-Path $ReportDir "$safeName.report.md"
    if (-not (Test-Path $rptPath)) {
        Write-Host "  ❌ 找不到報告：$rptPath" -ForegroundColor Red
        Write-Host "     請先執行掃描：.\scripts\test-compat.ps1 -File $File"
        exit 1
    }
    $now = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $confirm_section = @"

---

## 🌐 跨瀏覽器手動確認記錄

| 項目 | 結果 |
|---|---|
| **確認時間** | $now |
| **Chrome / Edge（主要品質驗收）** | ✅ 確認完成 |
| ↳ 頁面正常載入，無 JS 錯誤 | ✅ |
| ↳ 表單送出功能正常 | ✅ |
| ↳ AJAX 請求正常回應 | ✅ |
| ↳ 排版視覺正確，符合升級目標 | ✅ |
| ↳ opacity / rgba() 透明效果正確顯示 | ✅ |
| **IE11 文件模式 IE8（向下相容驗收）** | ✅ 確認完成 |
| ↳ 頁面可正常載入 | ✅ |
| ↳ 核心功能可操作 | ✅ |
| ↳ 無 JS 錯誤 | ✅ |
| ↳ 排版不錯亂（float 佈局正確） | ✅ |
| **整體狀態** | ✅ 靜態掃描 + 跨瀏覽器確認全部完成，可佈署 |

> 由 test-compat.ps1 --confirm 自動附加
"@
    Add-Content -Path $rptPath -Value $confirm_section -Encoding UTF8
    Write-Host ""
    Write-Host "  ✅ 跨瀏覽器確認結果已附加至報告" -ForegroundColor Green
    Write-Host "     $rptPath" -ForegroundColor DarkGray
    Write-Host ""
    Write-Host "  下一步：" -ForegroundColor Cyan
    Write-Host "    詢問是否將本次升級記錄到 DEPLOYMENT.md" -ForegroundColor White
    exit 0
}


function Write-Pass  { param($m) Write-Host "  ✅ PASS  $m" -ForegroundColor Green }
function Write-Fail  { param($m) Write-Host "  ❌ FAIL  $m" -ForegroundColor Red }
function Write-Warn  { param($m) Write-Host "  ⚠️  WARN  $m" -ForegroundColor Yellow }
function Write-Title { param($m) Write-Host "`n$m" -ForegroundColor Cyan }

$files = @()
if ($File -ne "") {
    $files = @(Get-Item $File)
} elseif ($Dir -ne "") {
    $files = Get-ChildItem -Path $Dir -Recurse -Include "*.asp","*.vs","*.vbs","*.inc","*.js","*.css" |
             Where-Object { $_.FullName -notmatch "\\node_modules\\" -and
                            $_.FullName -notmatch "\\jquery-" -and
                            $_.FullName -notmatch "\\jquery\." -and
                            $_.FullName -notmatch "\\html5shiv" -and
                            $_.FullName -notmatch "\\json2" -and
                            $_.FullName -notmatch "\\PIE" -and
                            $_.FullName -notmatch "\\reports\\" }
} else {
    Write-Host "用法：" -ForegroundColor Yellow
    Write-Host "  .\scripts\test-compat.ps1 -File page.asp"
    Write-Host "  .\scripts\test-compat.ps1 -Dir ."
    Write-Host "  .\scripts\test-compat.ps1 -File page.asp -ShowSections"
    Write-Host "  .\scripts\test-compat.ps1 -File page.asp -Section `"商品列表`""
    exit 1
}
if ($files.Count -eq 0) { Write-Host "找不到可掃描的檔案" -ForegroundColor Yellow; exit 1 }

# ── IE8 規則定義 ──────────────────────────────────────────
$jsRules = @(
    @{ Pattern = '\b(let|const)\b\s+\w+';            Msg = "禁用 let / const，改用 var" },
    @{ Pattern = '=>\s*[{(]|=>\s*\w';                Msg = "禁用箭頭函數 =>，改用 function(){}" },
    @{ Pattern = '`[^`]*\$\{';                        Msg = "禁用 template literal，改用字串串接" },
    @{ Pattern = '\.addEventListener\s*\(';           Msg = "禁用 addEventListener，改用 jQuery .on()" },
    @{ Pattern = '\bfetch\s*\(';                      Msg = "禁用 fetch API，改用 `$.ajax()" },
    @{ Pattern = '\bPromise\s*[\.(]';                 Msg = "禁用 Promise，改用 `$.ajax()" },
    @{ Pattern = '\.querySelector(All)?\s*\(';       Msg = "禁用 querySelector，改用 jQuery `$()" },
    @{ Pattern = '\bclass\s+\w+[\s{]';               Msg = "禁用 ES6 class，改用 prototype 模式" },
    @{ Pattern = '\bimport\s+.+from\s+[''"]';        Msg = "禁用 ES6 import" },
    @{ Pattern = '\bexport\s+(default\s+)?';          Msg = "禁用 ES6 export" },
    @{ Pattern = 'console\.log\s*\('; Exclude = 'window\.console'; Msg = "console.log 需加 if(window.console) 保護" },
    @{ Pattern = 'jquery[-_.]([2-9]|[1-9][0-9])\.'; Msg = "偵測到 jQuery 2.x+，必須用 1.12.4" }
)
$cssRules = @(
    @{ Pattern = 'display\s*:\s*flex';  Msg = "禁用 flexbox，改用 float + clearfix" },
    @{ Pattern = 'display\s*:\s*grid';  Msg = "禁用 CSS grid，改用 float" },
    @{ Pattern = 'grid-template';       Msg = "禁用 grid-template" },
    @{ Pattern = ':\s*calc\s*\(';       Msg = "禁用 calc()，改用固定 px 或 margin offset" },
    @{ Pattern = 'var\s*\(--';          Msg = "禁用 CSS 自訂變數 var(--)" },
    @{ Pattern = ':\s*[\d.]+rem\b';    Msg = "禁用 rem 單位，改用 px" }
)
$htmlRules = @(
    @{ Pattern = '<!DOCTYPE\s+html>'; Msg = "<!DOCTYPE html>"; Invert = $true },
    @{ Pattern = 'X-UA-Compatible';  Msg = "X-UA-Compatible meta"; Invert = $true }
)

# ── 回歸規則定義（偵測升級轉換錯誤）────────────────────
# 這些規則偵測「升級過程常見的誤改模式」
# 補充說明附在 HelpMsg，只列於報告，不在終端機重複輸出
$regressionJsRules = @(
    @{
        Pattern = 'function\s*\(\s*\)\s*\{\s*\}'
        Msg     = "回歸：發現空函式，可能是箭頭函數轉換不完整"
        HelpMsg = "原始箭頭函數有函式主體，轉換為 function(){} 時應保留主體邏輯"
    },
    @{
        Pattern = '\bvar\s+var\s+'
        Msg     = "回歸：重複的 var 宣告（var var），可能是多次處理同一行"
        HelpMsg = "合併為單一 var 宣告"
    },
    @{
        Pattern = '\$\.ajax\s*\(\s*\)'
        Msg     = "回歸：`$.ajax()` 呼叫無參數，可能是 fetch 轉換不完整"
        HelpMsg = "補回 url、method、data、success、error 等必要參數"
    },
    @{
        Pattern = '\bnull\b|\bundefined\b'
        Msg     = "回歸：發現裸 null 或 undefined 字串，可能是 template literal 轉換錯誤"
        HelpMsg = "確認字串串接邏輯是否正確，null/undefined 不應直接出現在拼接後的字串裡"
    }
)
$regressionCssRules = @(
    @{
        Pattern = 'float\s*:\s*left[^}]*float\s*:\s*left'
        Msg     = "回歸：同一規則集有重複 float:left，可能是 flex 轉換殘留"
        HelpMsg = "移除多餘的 float 宣告，保留一個即可"
    },
    @{
        Pattern = '::\s*after|::\s*before'
        Msg     = "回歸：發現雙冒號偽元素 ::after/::before，IE8 只支援單冒號"
        HelpMsg = "改為 :after / :before（單冒號）"
    }
)

# ── 解析 [SECTION] 標記 ──────────────────────────────────
function Get-Sections {
    param([string[]]$lines)
    $sections = [System.Collections.Generic.List[object]]::new()
    $pat = "'\s*\[SECTION\]\s*(.+?)\s*%>"
    $cur = $null
    for ($i = 0; $i -lt $lines.Count; $i++) {
        if ($lines[$i] -match $pat) {
            if ($null -ne $cur) { $cur.EndLine = $i; $sections.Add($cur) }
            $cur = [PSCustomObject]@{ Name = $Matches[1].Trim(); StartLine = $i + 1; EndLine = $lines.Count }
        }
    }
    if ($null -ne $cur) { $cur.EndLine = $lines.Count; $sections.Add($cur) }
    return $sections
}

# ── 邊界安全性分析 ────────────────────────────────────────
function Get-BoundaryRisk {
    param([string[]]$lines, [int]$lineNum1Based)
    $idx        = $lineNum1Based - 1
    $inScript   = $false
    $inStyle    = $false
    $inVbBlock  = $false
    $braceDepth = 0
    $parenDepth = 0

    for ($i = 0; $i -lt $idx; $i++) {
        $l = $lines[$i]

        # VBScript 多行區塊（排除 [SECTION] 注解行）
        if ($l -match '<%' -and $l -notmatch "'\s*\[SECTION\]") {
            $opens  = ([regex]::Matches($l, '<%')).Count
            $closes = ([regex]::Matches($l, '%>')).Count
            if ($opens -gt $closes) { $inVbBlock = $true }
            elseif ($closes -ge $opens -and $inVbBlock) { $inVbBlock = $false }
        } elseif ($l -match '%>' -and $inVbBlock) {
            $inVbBlock = $false
        }

        # <script> / </script>
        if ($l -match '<script[\s>]' -and $l -notmatch '</script>') { $inScript = $true }
        if ($l -match '</script>') { $inScript = $false; $braceDepth = 0 }

        # <style> / </style>
        if ($l -match '<style[\s>]' -and $l -notmatch '</style>') { $inStyle = $true }
        if ($l -match '</style>') { $inStyle = $false }

        # 大括號深度（在 script 內）
        if ($inScript) {
            $braceDepth += ([regex]::Matches($l, '\{')).Count
            $braceDepth -= ([regex]::Matches($l, '\}')).Count
            if ($braceDepth -lt 0) { $braceDepth = 0 }
        }

        # 小括號深度
        $parenDepth += ([regex]::Matches($l, '\(')).Count
        $parenDepth -= ([regex]::Matches($l, '\)')).Count
        if ($parenDepth -lt 0) { $parenDepth = 0 }
    }

    if ($inVbBlock)                        { return "在多行 VBScript <% ... %> 區塊內" }
    if ($inScript -and $braceDepth -gt 0)  { return "在 <script> 區塊的函式/物件內（{ } 深度 $braceDepth）" }
    if ($inScript)                         { return "在 <script> ... </script> 區塊內" }
    if ($inStyle)                          { return "在 <style> ... </style> 區塊內" }
    if ($parenDepth -gt 0)                 { return "在未關閉的括號內（深度 $parenDepth）" }
    return ""
}

# 尋找目標行往上最近的安全邊界
function Find-SafeBoundary {
    param([string[]]$lines, [int]$lineNum1Based)
    for ($i = $lineNum1Based - 2; $i -ge 0; $i--) {
        $l = $lines[$i]
        if ($l -match '</script>' -or $l -match '</style>' -or
            $l -match '%>'        -or $l -match '</div>'   -or
            $l -match '</table>'  -or $l -match '</form>') {
            return $i + 2
        }
    }
    return -1
}

# ── 快速計算區段問題數 ────────────────────────────────────
function Count-SectionIssues {
    param([string[]]$sLines, [string]$ext)
    $n = 0
    $allRules = @()
    if ($ext -in ".asp",".vs",".vbs",".inc",".js") { $allRules += $jsRules }
    if ($ext -in ".asp",".vs",".inc",".css")         { $allRules += $cssRules }
    foreach ($rule in $allRules) {
        foreach ($line in $sLines) {
            if ($ext -in ".asp",".vs",".inc",".vbs" -and $line -match '<%') { continue }
            if ($line -match $rule.Pattern) {
                if ($rule.Exclude -and $line -match $rule.Exclude) { continue }
                $n++; break
            }
        }
    }
    return $n
}

# ── ShowSections 模式（含邊界防呆）───────────────────────
function Show-Sections {
    param([System.IO.FileInfo]$f)
    $lines    = Get-Content $f.FullName -Encoding UTF8
    $ext      = $f.Extension.ToLower()
    $sections = Get-Sections -lines $lines

    Write-Title "[$($f.Name)] — 區段清單（共 $($lines.Count) 行）"

    if ($sections.Count -eq 0) {
        Write-Warn "此檔案沒有 [SECTION] 標記"
        Write-Host ""
        Write-Host "  建議在超過 800 行的大型檔案中加入分段標記，例如：" -ForegroundColor DarkYellow
        Write-Host "  <%' [SECTION] 頁面 Head %>"      -ForegroundColor DarkYellow
        Write-Host "  <%' [SECTION] 商品列表輸出 %>"   -ForegroundColor DarkYellow
        Write-Host "  <%' [SECTION] 表單與送出 %>"     -ForegroundColor DarkYellow
        Write-Host "  <%' [SECTION] 頁尾 Script %>"    -ForegroundColor DarkYellow
        Write-Host ""
        Write-Host "  ⚠️  標記必須放在 </script> </style> %> 之後，下一個區塊開始之前" -ForegroundColor DarkYellow
        return
    }

    $riskMap  = @{}
    $safeMap  = @{}
    $hasDanger = $false
    foreach ($s in $sections) {
        $risk = Get-BoundaryRisk -lines $lines -lineNum1Based $s.StartLine
        if ($risk -ne "") {
            $riskMap[$s.Name] = $risk
            $hasDanger = $true
            $at = Find-SafeBoundary -lines $lines -lineNum1Based $s.StartLine
            if ($at -gt 0) { $safeMap[$s.Name] = $at }
        }
    }

    Write-Host ""
    Write-Host ("  {0,-4} {1,-30} {2,-14} {3}" -f "#", "行號範圍", "狀態", "區段名稱") -ForegroundColor DarkCyan
    Write-Host ("  {0,-4} {1,-30} {2,-14} {3}" -f "--", "--------", "--", "--------")   -ForegroundColor DarkGray

    $idx = 1
    foreach ($s in $sections) {
        $sLines    = $lines[($s.StartLine-1)..($s.EndLine-1)]
        $lineCount = $s.EndLine - $s.StartLine + 1
        $range     = "行 $($s.StartLine)–$($s.EndLine)（$lineCount 行）"

        if ($riskMap.ContainsKey($s.Name)) {
            Write-Host ("  {0,-4} {1,-30} {2,-14} {3}" -f "#$idx", $range, "⚠️ 邊界危險", $s.Name) -ForegroundColor Yellow
            Write-Host ("       ↑ 標記位於：$($riskMap[$s.Name])") -ForegroundColor Red
            if ($safeMap.ContainsKey($s.Name)) {
                Write-Host ("       💡 建議移到行 $($safeMap[$s.Name]) 之後（最近的安全邊界）") -ForegroundColor DarkYellow
            } else {
                Write-Host ("       💡 請手動移到最近的 </script> </style> %> 或 </div> 之後") -ForegroundColor DarkYellow
            }
        } else {
            $n    = Count-SectionIssues -sLines $sLines -ext $ext
            $icon = if ($n -eq 0) { "✅ 安全" } else { "❌ 安全($n)" }
            Write-Host ("  {0,-4} {1,-30} {2,-14} {3}" -f "#$idx", $range, $icon, $s.Name) -ForegroundColor White
        }
        $idx++
    }

    Write-Host ""
    if ($hasDanger) {
        Write-Host "  ⚠️  請先修正上方標記位置，再進行 Copilot 升級。" -ForegroundColor Yellow
        Write-Host "  邊界危險的區段，Copilot 看到不完整的程式碼，有誤改後端邏輯的風險。" -ForegroundColor DarkRed
    } else {
        Write-Host "  ✅ 所有分段標記位置安全，可進行升級。" -ForegroundColor Green
        Write-Host ""
        Write-Host "  Copilot 升級指令（僅列出有問題的區段）：" -ForegroundColor DarkCyan
        foreach ($s in $sections) {
            $sLines = $lines[($s.StartLine-1)..($s.EndLine-1)]
            $n      = Count-SectionIssues -sLines $sLines -ext $ext
            if ($n -gt 0) {
                Write-Host "  升級 $($f.Name) 的 [$($s.Name)] 區段（行 $($s.StartLine)–$($s.EndLine)），跨瀏覽器相容" -ForegroundColor DarkGray
            }
        }
        Write-Host ""
        Write-Host "  掃描指定區段：" -ForegroundColor DarkCyan
        Write-Host "  .\scripts\test-compat.ps1 -File $($f.Name) -Section `"區段名稱`"" -ForegroundColor DarkYellow
    }
}

# ── 掃描單一檔案（全部或指定區段）───────────────────────
function Test-File {
    param([System.IO.FileInfo]$f, [string]$SectionName = "")

    $ext      = $f.Extension.ToLower()
    $content  = Get-Content $f.FullName -Raw -Encoding UTF8
    $allLines = Get-Content $f.FullName -Encoding UTF8
    $aspLike  = $ext -in ".asp",".vs",".inc"

    $scanLines       = $allLines
    $rangeLabel      = "全部 $($allLines.Count) 行"
    $lineOffset      = 0
    $boundaryWarning = ""

    if ($SectionName -ne "") {
        $sections = Get-Sections -lines $allLines
        $found    = $sections | Where-Object { $_.Name -eq $SectionName }
        if ($null -eq $found) {
            Write-Host "  ❌ 找不到區段：$SectionName" -ForegroundColor Red
            Write-Host "  請先執行 -ShowSections 查看可用區段" -ForegroundColor Yellow
            return ,@(0, 0, 0, 0, "")
        }

        $risk = Get-BoundaryRisk -lines $allLines -lineNum1Based $found.StartLine
        if ($risk -ne "") {
            $boundaryWarning = $risk
            $safeAt = Find-SafeBoundary -lines $allLines -lineNum1Based $found.StartLine
            Write-Host ""
            Write-Host "  ⚠️  邊界警告：[$SectionName] 的分段標記位於「$risk」" -ForegroundColor Yellow
            if ($safeAt -gt 0) {
                Write-Host "  💡 建議將標記移到行 $safeAt 之後再進行升級" -ForegroundColor DarkYellow
            }
            Write-Host "  ⛔ 繼續掃描，但使用此區段讓 Copilot 升級有誤改後端邏輯的風險" -ForegroundColor DarkRed
            Write-Host ""
        }

        $lineOffset = $found.StartLine - 1
        $scanLines  = $allLines[$lineOffset..($found.EndLine-1)]
        $rangeLabel = "[$SectionName] 行 $($found.StartLine)–$($found.EndLine)，共 $($scanLines.Count) 行"
    }

    $issues      = 0
    $regrIssues  = 0
    $passCount   = 0
    $regrPass    = 0
    $rPass  = [System.Collections.Generic.List[string]]::new()
    $rFail  = [System.Collections.Generic.List[string]]::new()
    $rWarn  = [System.Collections.Generic.List[string]]::new()
    $rRPass = [System.Collections.Generic.List[string]]::new()
    $rRFail = [System.Collections.Generic.List[string]]::new()
    $rDet   = [System.Collections.Generic.Dictionary[string,System.Collections.Generic.List[string]]]::new()
    $rHelp  = [System.Collections.Generic.Dictionary[string,string]]::new()

    Write-Title "[$($f.Name)]  ($rangeLabel)"

    # ── IE8 規則掃描 ─────────────────────────────────────
    Write-Host "  ── 語法合規規則（跨瀏覽器） ──" -ForegroundColor DarkCyan

    $rules = @()
    if ($ext -in ".asp",".vs",".vbs",".inc",".js") { $rules += $jsRules }
    if ($ext -in ".asp",".vs",".inc",".css")         { $rules += $cssRules }

    foreach ($rule in $rules) {
        $hits = [System.Collections.Generic.List[string]]::new()
        for ($i = 0; $i -lt $scanLines.Count; $i++) {
            if ($ext -in ".asp",".vs",".inc",".vbs" -and $scanLines[$i] -match '<%') { continue }
            if ($scanLines[$i] -match $rule.Pattern) {
                if ($rule.Exclude -and $scanLines[$i] -match $rule.Exclude) { continue }
                $hits.Add("行 $($i + 1 + $lineOffset)： $($scanLines[$i].Trim())")
            }
        }
        if ($hits.Count -gt 0) {
            Write-Fail $rule.Msg
            $hits | ForEach-Object { Write-Host "    $_" -ForegroundColor DarkRed }
            $rFail.Add($rule.Msg); $rDet[$rule.Msg] = $hits; $issues++
        } else {
            Write-Pass $rule.Msg; $rPass.Add($rule.Msg); $passCount++
        }
    }

    # opacity 雙寫檢查
    if ($ext -in ".asp",".vs",".inc",".css") {
        $sc = $scanLines -join "`n"
        if (($sc -match 'opacity\s*:') -and -not ($sc -match 'filter\s*:\s*alpha\s*\(opacity')) {
            Write-Fail "opacity 需同時加 filter:alpha(opacity=XX)"
            $rFail.Add("opacity 需同時加 filter:alpha(opacity=XX)"); $issues++
        } elseif ($sc -match 'opacity\s*:') {
            Write-Pass "opacity 有伴隨 filter:alpha"; $rPass.Add("opacity 有伴隨 filter:alpha"); $passCount++
        }
    }

    # rgba fallback 檢查
    if ($ext -in ".asp",".vs",".inc",".css") {
        $sc = $scanLines -join "`n"
        if ($sc -match 'rgba\s*\(') {
            # 簡單判斷：rgba 前一行是否有 solid 色
            $hasRgbaFallback = $false
            for ($i = 1; $i -lt $scanLines.Count; $i++) {
                if ($scanLines[$i] -match 'rgba\s*\(') {
                    if ($scanLines[$i-1] -match '#[0-9a-fA-F]{3,6}|background:\s*[a-z]+') {
                        $hasRgbaFallback = $true; break
                    }
                }
            }
            if (-not $hasRgbaFallback) {
                Write-Fail "rgba() 需在上方加 solid 降級色"
                $rFail.Add("rgba() 需在上方加 solid 降級色"); $issues++
            } else {
                Write-Pass "rgba() 有 solid 降級色"; $rPass.Add("rgba() 有 solid 降級色"); $passCount++
            }
        }
    }

    # HTML 規則（全檔且 ASP-like）
    if ($aspLike -and $SectionName -eq "") {
        foreach ($rule in $htmlRules) {
            $found2 = $content -match $rule.Pattern
            if ($rule.Invert) {
                if (-not $found2) { Write-Fail "缺少 $($rule.Msg)"; $rFail.Add("缺少 $($rule.Msg)"); $issues++ }
                else              { Write-Pass "有 $($rule.Msg)"; $rPass.Add("有 $($rule.Msg)"); $passCount++ }
            }
        }
    }

    # [ASP-UPGRADE] 標記計數
    $sc2       = $scanLines -join "`n"
    $markCount = ([regex]::Matches($sc2, '\[ASP-UPGRADE\]')).Count
    if ($markCount -gt 0) {
        Write-Pass "[ASP-UPGRADE] 標記存在（共 $markCount 處）"
        $rPass.Add("[ASP-UPGRADE] 標記存在（共 $markCount 處）"); $passCount++
    } else {
        Write-Warn "[ASP-UPGRADE] 找不到升級標記"
        $rWarn.Add("[ASP-UPGRADE] 找不到升級標記，請確認是否已完成升級")
    }

    # ── 回歸規則掃描 ─────────────────────────────────────
    Write-Host "  ── 回歸偵測規則（升級轉換錯誤）──" -ForegroundColor DarkCyan

    $regrRules = @()
    if ($ext -in ".asp",".vs",".vbs",".inc",".js") { $regrRules += $regressionJsRules }
    if ($ext -in ".asp",".vs",".inc",".css")         { $regrRules += $regressionCssRules }

    foreach ($rule in $regrRules) {
        $hits = [System.Collections.Generic.List[string]]::new()
        $fullBlock = $scanLines -join "`n"
        # 逐行掃描（CSS 多行規則用全文掃）
        if ($rule.Pattern -match '\\n' -or $rule.Msg -match 'CSS') {
            if ($fullBlock -match $rule.Pattern) {
                $hits.Add("（全文比對命中）")
            }
        } else {
            for ($i = 0; $i -lt $scanLines.Count; $i++) {
                if ($ext -in ".asp",".vs",".inc",".vbs" -and $scanLines[$i] -match '<%') { continue }
                if ($scanLines[$i] -match $rule.Pattern) {
                    $hits.Add("行 $($i + 1 + $lineOffset)： $($scanLines[$i].Trim())")
                }
            }
        }
        if ($hits.Count -gt 0) {
            Write-Fail $rule.Msg
            $hits | ForEach-Object { Write-Host "    $_" -ForegroundColor DarkRed }
            if ($rule.HelpMsg) {
                Write-Host "    💡 $($rule.HelpMsg)" -ForegroundColor DarkYellow
            }
            $rRFail.Add($rule.Msg)
            $rDet[$rule.Msg] = $hits
            if ($rule.HelpMsg) { $rHelp[$rule.Msg] = $rule.HelpMsg }
            $regrIssues++
        } else {
            Write-Pass $rule.Msg; $rRPass.Add($rule.Msg); $regrPass++
        }
    }

    # ── Markdown 報告 ────────────────────────────────────
    $now      = Get-Date -Format "yyyy-MM-dd HH:mm"
    $ie8Pass  = if ($issues -eq 0) { "✅ 通過" } else { "❌ 失敗 ($issues 項)" }
    $regrStat = if ($regrIssues -eq 0) { "✅ 通過" } else { "⚠️ 發現 $regrIssues 項" }
    $overall  = if ($issues -eq 0 -and $regrIssues -eq 0) { "✅ 全部通過" } else { "❌ 需修正" }

    $safeName = "$($f.BaseName)$($f.Extension -replace '\.','_')"
    if ($SectionName -ne "") { $safeName += "_$($SectionName -replace '\s','_')" }
    $rptPath  = Join-Path $ReportDir "$safeName.report.md"

    $sb = [System.Text.StringBuilder]::new()
    [void]$sb.AppendLine("# 跨瀏覽器相容性測試報告")
    [void]$sb.AppendLine("")
    [void]$sb.AppendLine("| 項目 | 內容 |")
    [void]$sb.AppendLine("|---|---|")
    [void]$sb.AppendLine("| **檔案名稱** | ``$($f.Name)`` |")
    [void]$sb.AppendLine("| **完整路徑** | ``$($f.FullName)`` |")
    [void]$sb.AppendLine("| **掃描範圍** | $rangeLabel |")
    [void]$sb.AppendLine("| **副檔名** | $ext |")
    [void]$sb.AppendLine("| **掃描時間** | $now |")
    if ($boundaryWarning -ne "") {
        [void]$sb.AppendLine("| **⚠️ 邊界警告** | 標記位於：$boundaryWarning |")
    }
    [void]$sb.AppendLine("| **IE8 規則** | $ie8Pass |")
    [void]$sb.AppendLine("| **回歸偵測** | $regrStat |")
    [void]$sb.AppendLine("| **整體結果** | $overall |")
    [void]$sb.AppendLine("| **語法合規通過** | $passCount 項 ✅ |")
    [void]$sb.AppendLine("| **語法合規失敗** | $issues 項 ❌ |")
    [void]$sb.AppendLine("| **回歸通過** | $regrPass 項 ✅ |")
    [void]$sb.AppendLine("| **回歸失敗** | $regrIssues 項 ⚠️ |")
    [void]$sb.AppendLine("| **[ASP-UPGRADE] 標記** | $markCount 處 |")
    [void]$sb.AppendLine("")

    if ($boundaryWarning -ne "") {
        [void]$sb.AppendLine("## ⚠️ 邊界安全警告")
        [void]$sb.AppendLine("")
        [void]$sb.AppendLine("此區段的分段標記位於危險位置：**$boundaryWarning**")
        [void]$sb.AppendLine("")
        [void]$sb.AppendLine("請將 ``<%' [SECTION] $SectionName %>`` 移到最近的 ``</script>``、``</style>``、``%>`` 或 ``</div>`` 之後，")
        [void]$sb.AppendLine("再使用此區段進行 Copilot 升級，否則有誤改後端邏輯的風險。")
        [void]$sb.AppendLine("")
    }

    if ($rFail.Count -gt 0) {
        [void]$sb.AppendLine("## ❌ 語法合規規則失敗（需修正）")
        [void]$sb.AppendLine("")
        foreach ($msg in $rFail) {
            [void]$sb.AppendLine("### $msg")
            [void]$sb.AppendLine("")
            if ($rDet.ContainsKey($msg)) {
                [void]$sb.AppendLine("發現位置：")
                [void]$sb.AppendLine('```')
                foreach ($l in $rDet[$msg]) { [void]$sb.AppendLine($l) }
                [void]$sb.AppendLine('```')
            }
            [void]$sb.AppendLine("")
        }
    }

    if ($rRFail.Count -gt 0) {
        [void]$sb.AppendLine("## ⚠️ 回歸偵測失敗（轉換錯誤，需確認）")
        [void]$sb.AppendLine("")
        [void]$sb.AppendLine("> 回歸規則偵測升級轉換過程中常見的錯誤模式。發現時請確認原始邏輯是否完整保留。")
        [void]$sb.AppendLine("")
        foreach ($msg in $rRFail) {
            [void]$sb.AppendLine("### $msg")
            [void]$sb.AppendLine("")
            if ($rHelp.ContainsKey($msg)) {
                [void]$sb.AppendLine("💡 **修正建議**：$($rHelp[$msg])")
                [void]$sb.AppendLine("")
            }
            if ($rDet.ContainsKey($msg)) {
                [void]$sb.AppendLine("發現位置：")
                [void]$sb.AppendLine('```')
                foreach ($l in $rDet[$msg]) { [void]$sb.AppendLine($l) }
                [void]$sb.AppendLine('```')
            }
            [void]$sb.AppendLine("")
        }
    }

    if ($rWarn.Count -gt 0) {
        [void]$sb.AppendLine("## ⚠️ 警告項目")
        [void]$sb.AppendLine("")
        foreach ($msg in $rWarn) { [void]$sb.AppendLine("- $msg") }
        [void]$sb.AppendLine("")
    }

    if ($rPass.Count -gt 0) {
        [void]$sb.AppendLine("## ✅ 語法合規規則通過")
        [void]$sb.AppendLine("")
        foreach ($msg in $rPass) { [void]$sb.AppendLine("- $msg") }
        [void]$sb.AppendLine("")
    }

    if ($rRPass.Count -gt 0) {
        [void]$sb.AppendLine("## ✅ 回歸偵測通過")
        [void]$sb.AppendLine("")
        foreach ($msg in $rRPass) { [void]$sb.AppendLine("- $msg") }
        [void]$sb.AppendLine("")
    }

    if ($issues -eq 0 -and $regrIssues -eq 0) {
        [void]$sb.AppendLine("## 🌐 跨瀏覽器確認清單")
        [void]$sb.AppendLine("")
        [void]$sb.AppendLine("語法合規與回歸偵測通過，佈署前請依序手動確認：")
        [void]$sb.AppendLine("")
        [void]$sb.AppendLine("**Chrome / Edge（現代瀏覽器）— 主要品質驗收**")
        [void]$sb.AppendLine("- [ ] 頁面正常載入，無 JS 錯誤（F12 Console）")
        [void]$sb.AppendLine("- [ ] 表單送出功能正常")
        [void]$sb.AppendLine("- [ ] AJAX 請求正常回應（F12 Network）")
        [void]$sb.AppendLine("- [ ] 排版視覺正確，符合升級目標")
        [void]$sb.AppendLine("- [ ] opacity / rgba() 透明效果正確顯示")
        [void]$sb.AppendLine("")
        [void]$sb.AppendLine("**IE11 文件模式 IE8（F12 → 文件模式 → 8）— 向下相容驗收**")
        [void]$sb.AppendLine("- [ ] 頁面可正常載入")
        [void]$sb.AppendLine("- [ ] 核心功能可操作（表單、互動、AJAX）")
        [void]$sb.AppendLine("- [ ] 無 JS 錯誤（F12 Console）")
        [void]$sb.AppendLine("- [ ] 排版不錯亂（float 佈局正確）")
        [void]$sb.AppendLine("")
    }

    if ($SectionName -ne "") {
        [void]$sb.AppendLine("## 📋 下一步")
        [void]$sb.AppendLine("")
        [void]$sb.AppendLine($(if ($issues -eq 0 -and $regrIssues -eq 0) {
            "此區段通過，執行以下指令查看其他區段狀態："
        } else {
            "修正後重新掃描，或查看所有區段狀態："
        }))
        [void]$sb.AppendLine('```powershell')
        [void]$sb.AppendLine(".\scripts\test-compat.ps1 -File $($f.Name) -ShowSections")
        [void]$sb.AppendLine('```')
        [void]$sb.AppendLine("")
    }

    [void]$sb.AppendLine("---")
    [void]$sb.AppendLine("")
    $totalFail = $issues + $regrIssues
    [void]$sb.AppendLine($(if ($totalFail -eq 0) {
        "> ✅ 語法合規與回歸偵測全部通過。請依序完成 Chrome/Edge（主要品質）與 IE8（向下相容）手動確認後再佈署。"
    } else {
        "> ❌ 請修正上述 $totalFail 個問題後重新掃描。"
    }))

    $sb.ToString() | Out-File -FilePath $rptPath -Encoding UTF8
    Write-Host "  📄 報告：$rptPath" -ForegroundColor DarkCyan

    return ,@($issues, $passCount, $markCount, $regrIssues, $rptPath)
}

# ── 主執行 ────────────────────────────────────────────────
Write-Host "`n===================================================" -ForegroundColor Cyan
Write-Host "  Classic ASP 跨瀏覽器相容性掃描（現代化優先，向下相容 IE8）" -ForegroundColor Cyan
$modeStr = if ($ShowSections) { "顯示區段清單（含邊界安全檢查）" } elseif ($Section -ne "") { "區段掃描 [$Section]" } else { "全檔掃描" }
Write-Host "  模式：$modeStr" -ForegroundColor Magenta
Write-Host "  $(Get-Date -Format 'yyyy-MM-dd HH:mm')" -ForegroundColor Cyan
Write-Host "===================================================" -ForegroundColor Cyan

if ($ShowSections) {
    foreach ($f in $files) { Show-Sections -f $f }
    exit 0
}

$totalIssues     = 0
$totalRegrIssues = 0
$totalFiles      = 0
$fileResults     = [System.Collections.Generic.List[object]]::new()

foreach ($f in $files) {
    $r = Test-File -f $f -SectionName $Section
    $totalIssues     += $r[0]
    $totalRegrIssues += $r[3]
    $totalFiles++
    $fileResults.Add([PSCustomObject]@{
        Name        = $f.Name
        Issues      = $r[0]
        Pass        = $r[1]
        Marks       = $r[2]
        RegrIssues  = $r[3]
        Status      = if ($r[0] -eq 0 -and $r[3] -eq 0) { "✅ 通過" } elseif ($r[0] -gt 0) { "❌ 失敗" } else { "⚠️ 回歸" }
        ReportPath  = $r[4]
    })
}

# 總結報告
$now         = Get-Date -Format "yyyy-MM-dd HH:mm"
$summaryPath = Join-Path $ReportDir "_summary.report.md"
$ss = [System.Text.StringBuilder]::new()
[void]$ss.AppendLine("# 跨瀏覽器相容性掃描 — 總結報告")
[void]$ss.AppendLine("")
[void]$ss.AppendLine("| 項目 | 內容 |")
[void]$ss.AppendLine("|---|---|")
[void]$ss.AppendLine("| **掃描時間** | $now |")
[void]$ss.AppendLine("| **掃描模式** | $modeStr |")
[void]$ss.AppendLine("| **掃描檔案數** | $totalFiles |")
[void]$ss.AppendLine("| **語法合規問題數** | $totalIssues |")
[void]$ss.AppendLine("| **回歸問題數** | $totalRegrIssues |")
$finalStatus = if ($totalIssues -eq 0 -and $totalRegrIssues -eq 0) { "✅ 全部通過" } elseif ($totalIssues -gt 0) { "❌ 語法合規失敗" } else { "⚠️ 回歸偵測警告" }
[void]$ss.AppendLine("| **整體結果** | $finalStatus |")
[void]$ss.AppendLine("")
[void]$ss.AppendLine("## 各檔案結果")
[void]$ss.AppendLine("")
[void]$ss.AppendLine("| 檔案 | 結果 | 語法合規 | 合規失敗 | 回歸警告 | 標記數 | 報告 |")
[void]$ss.AppendLine("|---|---|---|---|---|---|---|")
foreach ($r in $fileResults) {
    $rel = Split-Path $r.ReportPath -Leaf
    [void]$ss.AppendLine("| ``$($r.Name)`` | $($r.Status) | $($r.Pass) ✅ | $($r.Issues) ❌ | $($r.RegrIssues) ⚠️ | $($r.Marks) 處 | [查看](./$rel) |")
}
[void]$ss.AppendLine("")

if ($totalIssues -eq 0 -and $totalRegrIssues -eq 0) {
    [void]$ss.AppendLine("## 🌐 跨瀏覽器確認清單")
    [void]$ss.AppendLine("")
    [void]$ss.AppendLine("語法合規與回歸偵測全部通過，佈署前請依序手動確認：")
    [void]$ss.AppendLine("")
    [void]$ss.AppendLine("**Chrome / Edge（現代瀏覽器）— 主要品質驗收**")
    [void]$ss.AppendLine("- [ ] 所有升級頁面正常載入，無 JS 錯誤（F12 Console）")
    [void]$ss.AppendLine("- [ ] 表單送出功能正常")
    [void]$ss.AppendLine("- [ ] AJAX 請求正常回應（F12 Network）")
    [void]$ss.AppendLine("- [ ] 排版視覺正確，符合升級目標")
    [void]$ss.AppendLine("- [ ] opacity / rgba() 透明效果正確顯示")
    [void]$ss.AppendLine("")
    [void]$ss.AppendLine("**IE11 文件模式 IE8（F12 → 文件模式 → 8）— 向下相容驗收**")
    [void]$ss.AppendLine("- [ ] 頁面可正常載入")
    [void]$ss.AppendLine("- [ ] 核心功能可操作（表單、互動、AJAX）")
    [void]$ss.AppendLine("- [ ] 無 JS 錯誤（F12 Console）")
    [void]$ss.AppendLine("- [ ] 排版不錯亂（float 佈局正確）")
    [void]$ss.AppendLine("")
}

[void]$ss.AppendLine("---")
[void]$ss.AppendLine("")
[void]$ss.AppendLine($(if ($totalIssues -eq 0 -and $totalRegrIssues -eq 0) {
    "> ✅ 所有檔案通過靜態掃描與回歸偵測，請完成跨瀏覽器手動確認後佈署。"
} elseif ($totalIssues -gt 0) {
    "> ❌ 請點擊各檔案報告連結，修正語法合規失敗項目後重新掃描。"
} else {
    "> ⚠️ 語法合規通過，但有回歸偵測警告。請確認轉換邏輯是否完整後再佈署。"
}))

$ss.ToString() | Out-File -FilePath $summaryPath -Encoding UTF8

Write-Host "`n===================================================" -ForegroundColor Cyan
Write-Host "  掃描完成：$totalFiles 個檔案" -ForegroundColor Cyan
Write-Host "  總結報告：.\$summaryPath" -ForegroundColor Cyan

if ($totalIssues -eq 0 -and $totalRegrIssues -eq 0) {
    Write-Host "  結果：✅ 全部通過（語法合規 + 回歸偵測）" -ForegroundColor Green
    Write-Host ""
    Write-Host "  ✅ 語法合規通過，佈署前請依序完成以下手動確認：" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "  【Chrome / Edge（現代瀏覽器）— 主要品質驗收】" -ForegroundColor DarkCyan
    Write-Host "    □ 頁面正常載入，無 JS 錯誤（F12 Console）" -ForegroundColor White
    Write-Host "    □ 表單送出功能正常" -ForegroundColor White
    Write-Host "    □ AJAX 請求正常回應（F12 Network）" -ForegroundColor White
    Write-Host "    □ 排版視覺正確，符合升級目標" -ForegroundColor White
    Write-Host "    □ opacity / rgba() 透明效果正確顯示" -ForegroundColor White
    Write-Host ""
    Write-Host "  【IE11 文件模式 IE8（F12 → 文件模式 → 8）— 向下相容驗收】" -ForegroundColor DarkCyan
    Write-Host "    □ 頁面可正常載入" -ForegroundColor White
    Write-Host "    □ 核心功能可操作（表單、互動、AJAX）" -ForegroundColor White
    Write-Host "    □ 無 JS 錯誤（F12 Console）" -ForegroundColor White
    Write-Host "    □ 排版不錯亂（float 佈局正確）" -ForegroundColor White
    Write-Host ""
    exit 0
} elseif ($totalIssues -gt 0) {
    Write-Host "  結果：❌ 語法合規 $totalIssues 個問題，回歸偵測 $totalRegrIssues 個警告" -ForegroundColor Red
    exit 1
} else {
    Write-Host "  結果：⚠️ 語法合規通過，但有 $totalRegrIssues 個回歸警告，請確認" -ForegroundColor Yellow
    exit 2
}
